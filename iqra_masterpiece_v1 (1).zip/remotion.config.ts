import { Config } from "@remotion/cli/config";

// Portable config: no absolute paths, no browser executable.
Config.setVideoImageFormat("jpeg");
Config.setJpegQuality(92);
Config.setOverwriteOutput(true);
Config.setConcurrency(2);
