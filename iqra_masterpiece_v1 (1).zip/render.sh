#!/usr/bin/env bash
# Renders the full video to out/video.mp4 (1080x1920, 30fps, H.264 high quality).
set -e
mkdir -p out
npx remotion render src/index.ts Iqra out/video.mp4 --codec=h264 --crf=18 --concurrency=2 --timeout=120000
echo "Done: out/video.mp4"
ls -lh out/video.mp4
