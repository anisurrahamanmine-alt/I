#!/usr/bin/env bash
# Serves the out/ folder on port 8080 so you can open the forwarded link in a new tab and download video.mp4.
cd "$(dirname "$0")/out" || { echo "out/ not found - run npm run render first"; exit 1; }
echo "Open the PORTS tab -> port 8080 -> open in browser -> tap video.mp4 to download."
python3 -m http.server 8080 2>/dev/null || npx --yes http-server -p 8080 .
