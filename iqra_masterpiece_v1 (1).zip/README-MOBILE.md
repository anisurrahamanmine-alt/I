# ইকরা ভিডিও — Android থেকে GitHub Codespaces-এ রেন্ডার

1. GitHub-এ নতুন repository খুলুন (যেমন `iqra-video`), তারপর **Code → Codespaces → Create codespace** দিন।
2. Codespace খুললে বাঁদিকের Explorer-এ `iqra_masterpiece_v1.zip` আপলোড করুন (ড্র্যাগ বা Upload)।
3. Terminal-এ `COMMANDS.txt`-এর কমান্ডগুলো ক্রমানুসারে চালান:
   - `unzip -o iqra_masterpiece_v1.zip`
   - `npm install`
   - `npm run setup` (প্রথমবার, Chrome লাইব্রেরি বসায়)
   - `npm run render` (৩০৯৬ ফ্রেম, ৪-কোর Codespace-এ মোটামুটি ১৫–৩০ মিনিট)
4. `out/video.mp4` ফাইলে Explorer থেকে লং-প্রেস করে **Download** দিন।
5. ডাউনলোড না হলে `npm run download` চালান → **PORTS** ট্যাবে 8080 → গ্লোব আইকন → নতুন ট্যাবে `video.mp4` চাপুন।

বিকল্প: repo-তে ফাইলগুলো push করলে **Actions → Render video → Run workflow** থেকেও রেন্ডার করা যায়; শেষে Artifacts থেকে MP4 নামাবেন।

ফরম্যাট: ৯:১৬, ১০৮০×১৯২০, ৩০fps, ১০৩.২ সেকেন্ড। রেশিও বদলাতে `src/config.ts` দেখুন।
