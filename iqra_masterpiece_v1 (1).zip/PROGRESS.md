# PROGRESS — iqra_masterpiece (ইসলামের প্রথম নির্দেশ: ইকরা — সূরা আল-আলাক ৯৬:১)

## ১. টপিক ও ফরম্যাট
- টপিক: আল্লাহর প্রথম নির্দেশ "اقْرَأْ" (ইকরা = পড়ো), সূরা আল-আলাক ৯৬:১
- অডিও: public/audio/voiceover.mp3 — ১০১.৬৪ সেকেন্ড; ভিডিও ১০৩.২ সেকেন্ড (৩০৯৬ ফ্রেম, শেষে ~১.৫ সেকেন্ড আউটরো হোল্ড)
- রেশিও: ৯:১৬, ১০৮০×১৯২০, ৩০fps (src/config.ts-এ এক জায়গায়)

## ২. সিদ্ধান্ত
- স্টাইল: ব্যবহারকারীর মাস্টার প্রম্পট "Modern Islamic Knowledge & Illumination Editorial" — সেভ করা স্কিল (diagram-explainer-style) ইচ্ছাকৃতভাবে ব্যবহার করা হয়নি (ব্যবহারকারীর নির্দেশ)
- রঙ (ব্যবহারকারী দিয়েছেন): Alabaster #FAF9F5, Sapphire #141E30, Teal #0D9488, Champagne #FDE68A, Burnished Gold #D97706 (শুধু বর্ডার/রিং), Ruby #BE123C, Slate #27303F
- ফন্ট: Baloo Da 2 ExtraBold (Google Fonts থেকে নামানো), Hind Siliguri SemiBold/Bold, Tiro Bangla, Tatsam Bengali (ফলব্যাক), Amiri Quran + Scheherazade New (আরবি, Google Fonts থেকে নামানো)
- মোশনের মেজাজ: গম্ভীর-শ্রদ্ধাশীল কিন্তু কৌতূহল জাগানো — মসৃণ স্প্রিং (ওভারশুট কম), শুধু হুক/ক্লাইম্যাক্স/"ছিল না!"-তে পাঞ্চ
- সাউন্ড: ZIP থেকে ২৬টা (নরমালাইজ করে public/sfx/*.wav), কোডে বানানো ৬টা: chime_spiritual, chime_deep, slash, swell_warm, tick_soft, ripple। মিউজিক নেই। SFX ভলিউম ০.১৬–০.২৫

## ৩. SRT সংশোধন (১১টা) — src_inputs/Read_corrected.srt
কোনটাই→কোনোটাই, কোন→কোনো (৫ বার), লিটারেলি→লিটারালি, জীবন ব্যবস্থার→জীবনব্যবস্থার, যাকে→যাঁকে, important→ইম্পর্টেন্ট, বিসমিরব্বিকাল্লাজি→বিসমি রাব্বিকাল্লাজি
সন্দেহ: ৫১.৫ সে "সর্বপ্রথমই" (স্ক্রিপ্টে সর্বপ্রথমেই — অডিওর মতো রাখা হয়েছে); ৫৩.৩–৫৬.৭ সে আরবি আয়াতের বাংলা প্রতিবর্ণ
শব্দ-টাইমিং: SRT কিউ + অডিওর নীরবতা-ম্যাপ থেকে বানানো (src/words.json), গুরুত্বপূর্ণ জায়গা (ইকরা, আরবি আয়াত, সিন ৯–১০) হাতে মেলানো

## ৪. সিন-তালিকা (ফ্রেম, পরম)
| সিন | ফ্রেম | অবস্থা |
|---|---|---|
| 01 হুক + বার চার্ট | 0–256 | শেষ |
| 02 "ছিল না!" + রহস্য সিল | 256–501 | শেষ |
| 03 ইকরা ক্লাইম্যাক্স | 501–775 | শেষ |
| 04 চিন্তাশীল চরিত্র + ২×২ গ্রিড | 775–1070 | শেষ |
| 05 পরিচয়-চেকলিস্ট | 1070–1544 | শেষ |
| 06 হেরা গুহা + আয়াত কার্ড | 1544–1833 | শেষ |
| 07 সাধারণ নয় + গভীরতার স্তর | 1833–2199 | শেষ |
| 08 পিরামিড | 2199–2423 | শেষ |
| 09 অন্ধ বিশ্বাস বনাম জ্ঞান | 2423–2705 | শেষ |
| 10 আসল মিশন | 2705–2849 | শেষ |
| 11 ভোরের আকাশ CTA | 2849–3096 | শেষ |

## ৫. এখন কোন ধাপে
ধাপ ৬–৭ (ডেলিভারি) — সব ১১টা সিন শেষ; tsc পাস; ৩০টা স্টিল ফ্রেম ও ৩ সেকেন্ডের টেস্ট রেন্ডার (অডিওসহ) যাচাই করা; absolute পাথ নেই

## ৬. পরের কাজ
ব্যবহারকারী Codespaces-এ রেন্ডার করবেন (COMMANDS.txt)। সংশোধন চাইলে সংশ্লিষ্ট src/scenes/SceneNN.tsx বদলে নতুন ZIP (v2)

## ৭. স্কিল
কোনো সেভ করা স্কিল নয় — ব্যবহারকারীর মাস্টার প্রম্পটই একমাত্র নির্দেশিকা (এই চ্যাটে দেওয়া)। ডেলিভারি: GitHub Codespaces (Android থেকে), এক ZIP।

## সাউন্ড কোথায় (সংক্ষেপে)
S1 whoosh_open+pop+৩ tick+chime · S2 record_stop+৩ slash+boom_deep+riser+zoom_through · S3 pop+২ slash+swoosh+riser+boom+chime_deep · S4 pop_soft+৪ card pop+ding+swoosh · S5 paper_slide+৪ type_tick+paper_rustle+swell · S6 shimmer+chime_spiritual+paper_slide+marker_sweep+swoosh · S7 pop_soft+pop+slash+swoosh+tick+chime_deep+swoosh · S8 thud_heavy+tick+২ pop+confirm+swoosh · S9 paper_slide+stamp_thud+chime+pop+swoosh+zoom_through · S10 page_flip+tick+chime_deep+swell · S11 swell+pop+shimmer+ui_click+ripple+chime
