#!/usr/bin/env bash
# One-time setup for GitHub Codespaces / Linux: system libraries for headless Chrome + Remotion browser.
set -e
if command -v apt-get >/dev/null 2>&1; then
  SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
  $SUDO apt-get update -y
  $SUDO apt-get install -y --no-install-recommends \
    libnss3 libdbus-1-3 libatk1.0-0 libatk-bridge2.0-0 libgbm1 libasound2 libxrandr2 \
    libxkbcommon0 libxfixes3 libxcomposite1 libxdamage1 libpango-1.0-0 libcairo2 libcups2 \
    libdrm2 libxshmfence1 fonts-noto-color-emoji ca-certificates || \
  $SUDO apt-get install -y --no-install-recommends libnss3 libgbm1 libasound2t64 libxkbcommon0 libpango-1.0-0 libcairo2 libcups2t64 || true
fi
npx remotion browser ensure
echo "Setup complete. Now run: npm run render"
