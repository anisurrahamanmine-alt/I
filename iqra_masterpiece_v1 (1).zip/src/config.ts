// ---- Single place for format (aspect ratio) ----
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const FPS = 30;

// Safe zones (9:16)
export const SAFE = {
  topBuffer: 140,
  stageTop: 160,
  stageBottom: 1320,
  opticalCenter: 720,
  captionTop: 1380,
  captionBottom: 1620,
  bottomBuffer: 1660,
  rightBuffer: 110,
  maxTextWidth: 880,
};

export const C = {
  alabaster: "#FAF9F5",
  ivory: "#FFFEFA",
  sapphire: "#141E30",
  teal: "#0D9488",
  champagne: "#FDE68A",
  gold: "#D97706",
  ruby: "#BE123C",
  slate: "#27303F",
  hairline: "#E5E7EB",
  periwinkle: "#8EA2E8",
  mint: "#7DD3C0",
  white: "#FFFFFF",
};

export const FONT = {
  hero: "'BalooDa2', 'TatsamBengali', 'HindSiliguri', sans-serif",
  body: "'HindSiliguri', 'TatsamBengali', sans-serif",
  serif: "'TiroBangla', 'HindSiliguri', serif",
  arabic: "'AmiriQuran', 'ScheherazadeNew', serif",
};

// Typography scale (Rule 12): key word >= 1.6x connecting
export const TYPE = {
  small: 54,
  big: 104,
  climax: 185,
};

export const SHADOW =
  "0 34px 70px -28px rgba(20,30,48,0.32), 0 10px 24px -6px rgba(20,30,48,0.10)";
