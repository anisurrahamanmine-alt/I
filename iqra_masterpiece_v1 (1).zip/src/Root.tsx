import React from "react";
import { Composition } from "remotion";
import { Video } from "./Video";
import { FPS, HEIGHT, WIDTH } from "./config";
import { TOTAL_FRAMES } from "./timeline";

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Iqra"
    component={Video}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
