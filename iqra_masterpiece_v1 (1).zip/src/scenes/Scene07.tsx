import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { draw, ease, easeIn, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { Chip, EdCard } from "../components/EdCard";
import { Cross, QMark } from "../components/Icons";
import { KText } from "../components/KText";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";
import { IqraAnchor } from "./Scene04";

const at = localAt(7);
const END = seqDur(7);

const BANDS = [
  { t: "চিন্তা", w: 560, bg: "rgba(13,148,136,0.14)", fg: C.sapphire, k: 165 },
  { t: "সভ্যতা", w: 700, bg: "rgba(20,30,48,0.10)", fg: C.sapphire, k: 166 },
  { t: "জ্ঞান", w: 820, bg: C.teal, fg: C.white, k: 168 },
];

/** Scene 7 — Not ordinary: "সাধারণ / গুরুত্বহীন" struck out, then the depth-layers diagram. */
export const Scene07: React.FC = () => {
  const f = useCurrentFrame();
  const exitOthers = ease(f, END - 18, END - 4, 1, 0, easeIn);
  return (
    <AbsoluteFill>
      <CameraRig scene={7}>
        <Layer top={190}>
          <Anim at={-4} out={at(162) - 2} outDur={12} type="down" dist={40} exitType="up">
            <IqraAnchor label="প্রথম নির্দেশ" />
          </Anim>
        </Layer>

        <Layer>
          <Anim at={at(142)} out={at(146) - 2} outDur={10} type="up" exitType="up">
            <KText lines={[{ t: "এবার আপনি জাস্ট", kind: "small", at: at(142) }, { t: "ভাবেন...", kind: "gold", at: at(145) - 2, size: 120 }]} />
          </Anim>
        </Layer>
        <Layer>
          <Anim at={at(146)} out={at(156) - 4} outDur={10} type="up" exitType="up">
            <KText lines={[{ t: "স্বয়ং আল্লাহর পক্ষ থেকে আসা", kind: "small", at: at(146) }, { t: "এই প্রথম নির্দেশ", kind: "gold", at: at(151) }]} />
          </Anim>
        </Layer>

        {/* Misconception tag struck out */}
        <Layer>
          <Anim at={at(156) - 2} out={at(161) + 8} outDur={10} type="pop" exitType="left" cfg="hero">
            <div style={{ position: "relative" }}>
              <Chip style={{ padding: "26px 50px", gap: 20 }}>
                <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 84, color: C.ruby, lineHeight: 1.2, paddingTop: 6 }}>সাধারণ / গুরুত্বহীন</span>
                <QMark size={64} color={C.gold} />
              </Chip>
              {f >= at(159) ? (
                <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", transform: `scale(${0.7 + 0.3 * sp(f, at(159), "punch")})` }}>
                  <Cross size={230} p={draw(f, at(159), 10)} sw={9} />
                </div>
              ) : null}
            </div>
          </Anim>
        </Layer>

        {/* Depth / layers diagram */}
        <Layer>
          <Anim at={at(162)} out={END} outDur={6} type="up" exitType="up">
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 24 }}>
              <div style={{ opacity: exitOthers }}>
                <KText lines={[{ t: "এর মাঝে লুকিয়ে আছে", kind: "small", at: at(162) }, { t: "গভীর তাৎপর্য!", kind: "teal", at: at(165) - 2, size: 112 }]} />
              </div>
              <EdCard w={880} pad={30}>
                <DepthDiagram f={f} start={at(162) + 4} exitK={exitOthers} />
              </EdCard>
              <div style={{ height: 70, opacity: exitOthers }}>
                <Anim at={at(170) - 2} type="pop" cfg="punch">
                  <Chip style={{ background: C.sapphire, border: `2px solid ${C.gold}`, padding: "8px 34px" }}>
                    <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 50, color: C.champagne, lineHeight: 1.2 }}>তাই না?</span>
                  </Chip>
                </Anim>
              </div>
            </div>
          </Anim>
        </Layer>
      </CameraRig>

      <Sfx at={at(142)} src="pop_soft" v={0.18} />
      <Sfx at={at(156) - 2} src="pop_a" v={0.18} />
      <Sfx at={at(159)} src="slash" v={0.2} />
      <Sfx at={at(161) + 2} src="swoosh_b" v={0.16} />
      <Sfx at={at(165)} src="tick_soft" v={0.2} />
      <Sfx at={at(168)} src="chime_deep" v={0.17} />
      <Sfx at={END - 14} src="swoosh_c" v={0.16} />
    </AbsoluteFill>
  );
};

const DepthDiagram: React.FC<{ f: number; start: number; exitK: number }> = ({ f, start, exitK }) => {
  const line = ease(f, start + 6, at(168) + 6, 0, 1);
  const wave = (f - start) * 0.12;
  return (
    <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "center", gap: 16 }}>
      {/* connector down the centre */}
      <svg width={20} height={470} style={{ position: "absolute", left: "50%", marginLeft: -10, top: 40, opacity: exitK }}>
        <line x1={10} y1={0} x2={10} y2={470} stroke={C.gold} strokeWidth={4} strokeDasharray="10 10" pathLength={1} strokeDashoffset={0} style={{ clipPath: `inset(0 0 ${100 - line * 100}% 0)` }} />
      </svg>
      <div style={{ opacity: exitK, zIndex: 1 }}>
        <Anim at={start} type="pop" cfg="hero">
          <div style={{ padding: "10px 34px", borderRadius: 999, background: C.champagne, border: `2px solid ${C.gold}`, fontFamily: FONT.body, fontWeight: 700, fontSize: 44, color: C.sapphire }}>
            একটি শব্দ: ইকরা
          </div>
        </Anim>
      </div>
      {/* waterline */}
      <svg width={820} height={30} viewBox="0 0 820 30" style={{ opacity: exitK * Math.min(1, ease(f, start + 4, start + 16)) }}>
        <path d={Array.from({ length: 42 }).map((_, i) => `${i === 0 ? "M" : "L"}${i * 20} ${15 + Math.sin(i * 0.8 + wave) * 6}`).join(" ")} fill="none" stroke={C.teal} strokeWidth={3} opacity={0.6} />
      </svg>
      {BANDS.map((b, i) => {
        const a = at(b.k) - 2;
        const glow = b.t === "জ্ঞান" ? 0.5 + 0.3 * Math.sin((f - a) * 0.15) : 0;
        if (f < a) return <div key={i} style={{ height: 96 }} />;
        const k = sp(f, a, "hero");
        const isJ = b.t === "জ্ঞান";
        return (
          <div
            key={i}
            style={{
              zIndex: 1,
              width: b.w * (0.7 + 0.3 * k),
              height: 96,
              borderRadius: 48,
              background: b.bg,
              border: isJ ? `3px solid ${C.gold}` : `2px solid ${C.hairline}`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: Math.min(1, k * 1.5) * (isJ ? 1 : exitK),
              transform: `translateY(${(1 - k) * 30}px) scale(${isJ ? 1 + 0.05 * (1 - exitK) : 1})`,
              boxShadow: isJ ? `0 0 ${40 * glow}px rgba(253,230,138,${glow}), 0 16px 30px -16px rgba(13,148,136,0.6)` : undefined,
            }}
          >
            <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 58, color: b.fg, lineHeight: 1.2, paddingTop: 6 }}>{b.t}</span>
          </div>
        );
      })}
    </div>
  );
};
