import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { ease, easeIn, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { CHART_TOP, ExpectationChart } from "../components/ExpectationChart";
import { QMark, Star8 } from "../components/Icons";
import { KText } from "../components/KText";
import { Dust, Flash, TopLight, Vignette } from "../components/Light";
import { C } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(2);
const END = seqDur(2);

/** Scene 2 — Pattern interrupt: ruby strikes on THE SAME chart, "ছিল না!", then the mystery seal. */
export const Scene02: React.FC = () => {
  const f = useCurrentFrame();
  const strikes = [at(28), at(29), at(29) + 9];
  const chartOut = ease(f, at(31) + 4, at(31) + 20, 0, 1, easeIn);
  const light = ease(f, at(17), at(17) + 30, 0, 0.55) * (1 - ease(f, at(31), at(32), 0, 0.3)) + ease(f, at(32), at(32) + 30, 0, 0.35);
  const vig = ease(f, at(17), at(17) + 20, 0, 0.9);
  const boom = f >= at(30) ? Math.exp(-(f - at(30)) / 5) : 0;
  const shake = f >= at(30) && f < at(30) + 12 ? Math.sin((f - at(30)) * 2.2) * 9 * Math.exp(-(f - at(30)) / 5) : 0;

  return (
    <AbsoluteFill>
      <TopLight k={light} />
      <CameraRig scene={2} fg={<Dust k={ease(f, at(32), at(32) + 30, 0, 0.8)} y0={160} y1={1000} spread={260} />}>
        <div style={{ position: "absolute", inset: 0, transform: `translateX(${shake}px)` }}>
          {/* Same chart card from Scene 1 (shared element) — struck through, then slides away */}
          {f < at(31) + 22 ? (
            <Layer top={CHART_TOP}>
              <div
                style={{
                  opacity: 1 - chartOut,
                  transform: `translate(${-160 * chartOut}px, ${120 * chartOut}px) scale(${1 - 0.15 * chartOut})`,
                  filter: chartOut > 0.02 ? `blur(${chartOut * 4}px)` : undefined,
                }}
              >
                <ExpectationChart headerAt={-200} barAt={[-200, -200, -200]} strikeAt={strikes} />
              </div>
            </Layer>
          ) : null}

          {/* Kinetic text above the chart */}
          <Layer top={360}>
            <Anim at={at(17)} out={at(21) - 1} outDur={8} type="drop" cfg="punch" exitType="up">
              <KText lines={[{ t: "কিন্তু জানলে", kind: "small", at: at(17) }, { t: "অবাক হবেন", kind: "gold", at: at(19) - 2 }]} />
            </Anim>
          </Layer>
          <Layer top={360}>
            <Anim at={at(21)} out={at(28) - 1} outDur={8} type="up" exitType="up">
              <KText lines={[{ t: "আল্লাহর পক্ষ থেকে আসা", kind: "small", at: at(21) }, { t: "একদম প্রথম নির্দেশ", kind: "gold", at: at(25) }]} />
            </Anim>
          </Layer>
          <Layer top={330}>
            <Anim at={at(28)} out={at(32) - 1} outDur={10} type="up" exitType="up">
              <KText lines={[{ t: "এর কোনোটাই", kind: "small", at: at(28) }, { t: "ছিল না!", kind: "ruby", at: at(30) - 1, size: 138 }]} />
            </Anim>
          </Layer>

          {/* Mystery parchment seal under the top-down light */}
          <Layer top={420}>
            <Anim at={at(32) + 2} out={END} outDur={10} type="up" dist={160} cfg="slow" exitType="zoom">
              <MysterySeal f={f} start={at(32) + 2} />
            </Anim>
          </Layer>
          <Layer top={900}>
            <Anim at={at(32) + 6} out={END - 8} outDur={10} type="up">
              <KText lines={[{ t: "তাহলে কী ছিল", kind: "small", at: at(32) + 6 }, { t: "সেই প্রথম নির্দেশ?", kind: "gold", at: at(35) }]} />
            </Anim>
          </Layer>
        </div>
      </CameraRig>
      <Vignette k={vig} />
      <Flash k={boom} />

      <Sfx at={at(17) - 1} src="record_stop" v={0.13} />
      <Sfx at={strikes[0]} src="slash" v={0.2} />
      <Sfx at={strikes[1]} src="slash" v={0.2} />
      <Sfx at={strikes[2]} src="slash" v={0.2} />
      <Sfx at={at(30)} src="boom_deep" v={0.25} />
      <Sfx at={at(32)} src="riser_low" v={0.13} />
      <Sfx at={END - 14} src="zoom_through" v={0.2} />
    </AbsoluteFill>
  );
};

const MysterySeal: React.FC<{ f: number; start: number }> = ({ f, start }) => {
  const pulse = 1 + Math.sin((f - start) * 0.18) * 0.05;
  const ring = ease(f, start, start + 30, 0, 1, easeOut);
  const qk = sp(f, start + 10, "hero");
  return (
    <div style={{ position: "relative", width: 380, height: 380, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <svg width={380} height={380} viewBox="0 0 380 380" style={{ position: "absolute", inset: 0, transform: `rotate(${(f - start) * 0.4}deg)` }}>
        <circle cx={190} cy={190} r={176} fill="none" stroke={C.gold} strokeWidth={2.5} strokeDasharray="6 10" opacity={0.7 * ring} />
        <circle cx={190} cy={190} r={160} fill="none" stroke={C.gold} strokeWidth={3} pathLength={1} strokeDasharray={1} strokeDashoffset={1 - ring} />
      </svg>
      <div
        style={{
          width: 290,
          height: 290,
          borderRadius: 145,
          background: "radial-gradient(circle at 50% 38%, #FFFBEB 0%, #FDF1C7 60%, #F3DFA2 100%)",
          boxShadow: "0 30px 60px -20px rgba(20,30,48,0.45), inset 0 0 0 6px rgba(217,119,6,0.35)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          transform: `scale(${pulse})`,
          position: "relative",
        }}
      >
        <div style={{ position: "absolute", top: 18 }}>
          <Star8 size={44} color={C.gold} sw={5} />
        </div>
        <div style={{ transform: `scale(${0.4 + 0.6 * qk})`, opacity: qk }}>
          <QMark size={150} color={C.sapphire} sw={11} p={ease(f, start + 10, start + 30, 0, 1)} />
        </div>
      </div>
    </div>
  );
};
