import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { ease, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { Learner } from "../components/Characters";
import { EdCard } from "../components/EdCard";
import { Compass, Star8 } from "../components/Icons";
import { KText } from "../components/KText";
import { TopLight } from "../components/Light";
import { C } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(10);
const END = seqDur(10);

/** Scene 10 — The true mission: learner opens and raises a book, compass locks to North. */
export const Scene10: React.FC = () => {
  const f = useCurrentFrame();
  const lockK = sp(f, at(222), "punch");
  const rot = f < at(222) ? -220 + (f - 0) * 1.6 + Math.sin(f * 0.3) * 10 : -18 * (1 - lockK);
  return (
    <AbsoluteFill>
      <TopLight k={ease(f, 0, 30, 0, 0.35)} />
      <CameraRig scene={10}>
        <Layer>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 28 }}>
            <Anim at={-4} out={END} outDur={12} type="zoom" cfg="hero">
              <EdCard w={760} h={540} pad={0} ornate style={{ overflow: "hidden" }}>
                <div style={{ position: "absolute", inset: 0, borderRadius: 20, background: "radial-gradient(ellipse 70% 60% at 50% 20%, rgba(253,230,138,0.45), transparent 70%), linear-gradient(180deg, rgba(13,148,136,0.06), rgba(142,162,232,0.10))" }} />
                <div style={{ position: "absolute", left: 120, top: 40 }}>
                  <Learner at={0} openAt={at(219)} raiseAt={at(219) + 4} size={330} />
                </div>
                <div style={{ position: "absolute", right: 60, top: 50, transform: `scale(${0.6 + 0.4 * sp(f, 2, "hero")})` }}>
                  <div style={{ width: 170, height: 170, borderRadius: 85, background: C.ivory, boxShadow: "0 14px 30px -14px rgba(20,30,48,0.45)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <Compass size={150} rot={rot} p={ease(f, 0, 20, 0, 1, easeOut)} />
                  </div>
                  <div style={{ position: "absolute", left: 66, top: -46, opacity: lockK, transform: `scale(${lockK})` }}>
                    <Star8 size={40} color={C.gold} fill={C.champagne} />
                  </div>
                </div>
              </EdCard>
            </Anim>
            <Anim at={at(216) - 2} out={END} outDur={12} type="up">
              <KText
                gap={6}
                lines={[
                  { t: "একজন প্রকৃত মুসলিমের", kind: "small", at: at(216) - 2, size: 50 },
                  { t: "আসল মিশন", kind: "gold", at: at(219) - 2, size: 96 },
                  { t: "সবার আগে জ্ঞান অর্জন!", kind: "teal", at: at(222) - 2, size: 84, underline: true },
                ]}
              />
            </Anim>
          </div>
        </Layer>
      </CameraRig>

      <Sfx at={at(219)} src="page_flip" v={0.2} />
      <Sfx at={at(222)} src="tick_soft" v={0.22} />
      <Sfx at={at(222) + 4} src="chime_deep" v={0.16} />
      <Sfx at={END - 30} src="swell_warm" v={0.15} />
    </AbsoluteFill>
  );
};
