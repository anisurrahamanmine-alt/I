import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { ease, easeIn } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { CaveHira } from "../components/CaveHira";
import { Chip, EdCard } from "../components/EdCard";
import { Star8 } from "../components/Icons";
import { Dust, TopLight } from "../components/Light";
import { SacredVerseCard } from "../components/SacredVerseCard";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(6);
const END = seqDur(6);

/** Scene 6 — The sacred revelation (96:1): Cave Hira gallery card + RTL verse card with word-by-word illumination. No figures. */
export const Scene06: React.FC = () => {
  const f = useCurrentFrame();
  const verseAt = at(129) - 10;
  const fold = ease(f, END - 16, END, 0, 1, easeIn);
  const words = [at(129), at(130), at(131), at(131) + 20, at(132)];

  return (
    <AbsoluteFill>
      <TopLight k={ease(f, 0, 30, 0.6, 0.35)} floorY={1240} />
      <CameraRig scene={6} fg={<Dust k={0.9} y0={170} y1={1200} spread={320} n={24} />}>
        {/* Cave Hira — framed gallery card (not full-screen) */}
        <Layer top={170}>
          <Anim at={-2} out={END} outDur={14} type="up" dist={140} cfg="soft" dim={verseAt} dimTo={0.45}>
            <div style={{ transform: `translateY(${ease(f, verseAt - 6, verseAt + 20, 240, -30)}px)` }}>
              <EdCard w={880} pad={14} ornate>
                <div style={{ borderRadius: 12, overflow: "hidden", height: 470 }}>
                  <CaveHira w={852} h={470} lightAt={at(126) + 4} />
                </div>
              </EdCard>
            </div>
          </Anim>
        </Layer>
        <Layer top={950}>
          <Anim at={at(127)} out={verseAt + 6} outDur={10} type="up">
            <Chip style={{ gap: 14 }}>
              <Star8 size={30} color={C.gold} sw={6} />
              <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 44, color: C.sapphire }}>জাবালে নূর — হেরা গুহা</span>
            </Chip>
          </Anim>
        </Layer>

        {/* Sacred verse card in front */}
        <Layer top={560}>
          <div style={{ transform: `translateY(${-520 * fold}px) scale(${1 - 0.55 * fold})`, transformOrigin: "50% 0%", opacity: 1 - 0.3 * fold }}>
            <Anim at={verseAt} type="up" dist={120} cfg="slow">
              <SacredVerseCard
                wordAt={words}
                transAt={at(133) - 2}
                sweepAt={at(134)}
                sweepEnd={at(137) + 8}
                trans2At={at(138) - 2}
                citeAt={at(138) + 12}
              />
            </Anim>
          </div>
        </Layer>
      </CameraRig>

      <Sfx at={at(126) + 4} src="shimmer" v={0.15} />
      <Sfx at={words[0] - 2} src="chime_spiritual" v={0.18} />
      <Sfx at={at(133) - 2} src="paper_slide" v={0.2} />
      <Sfx at={at(134)} src="marker_sweep" v={0.2} />
      <Sfx at={END - 14} src="swoosh_a" v={0.16} />
    </AbsoluteFill>
  );
};
