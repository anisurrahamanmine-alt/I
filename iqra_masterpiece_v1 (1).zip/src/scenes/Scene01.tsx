import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { ease, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { CHART_TOP, ExpectationChart } from "../components/ExpectationChart";
import { QMark, Star8 } from "../components/Icons";
import { KText } from "../components/KText";
import { C } from "../config";
import { localAt } from "../timeline";

const at = localAt(1);

/** Scene 1 — The common assumption: 0-second two-beat sticker hook + public expectation bar chart. */
export const Scene01: React.FC = () => {
  const f = useCurrentFrame();

  // Beat 1 sticker hook (frame 0 already moving) -> settles into a headline, exits at Beat 2
  const settle = ease(f, 40, 62, 0, 1, easeOut);
  const hookScale = 1.08 - 0.08 * settle;
  const hookY = -40 * settle;
  const tiltK = sp(f, -4, "punch");
  const qBounce = sp(f, at(9) - 2, "punch");
  const qScale = f < at(9) - 2 ? 1 + Math.sin(f * 0.35) * 0.06 * (1 - settle) : 0.85 + 0.15 * qBounce + 0.12 * Math.sin((f - at(9)) * 0.5) * Math.exp(-(f - at(9)) / 12);

  // Beat 2 text lifts up when the chart arrives
  const lift = ease(f, 176, 200, 0, 1, easeOut);

  return (
    <AbsoluteFill>
      <CameraRig
        scene={1}
        fg={
          <AbsoluteFill>
            <SpeedStreaks f={f} />
            <Sparks f={f} start={-2} cx={540} cy={640} />
            <Sparks f={f} start={at(7)} cx={540} cy={700} small />
          </AbsoluteFill>
        }
      >
        {/* Beat 1 — sticker hook */}
        <Layer>
          <Anim at={-5} out={at(10) - 2} outDur={10} type="zoom" exitType="up" cfg="punch">
            <div style={{ transform: `translateY(${hookY}px) scale(${hookScale}) rotate(${-4 + 4 * tiltK}deg)`, display: "flex", flexDirection: "column", alignItems: "center" }}>
              <div
                style={{
                  padding: "34px 46px 40px",
                  borderRadius: 34,
                  background: C.ivory,
                  border: `6px solid ${C.white}`,
                  boxShadow: "0 30px 60px -24px rgba(20,30,48,0.35), 0 0 0 2px rgba(217,119,6,0.35)",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 8,
                }}
              >
                <KText
                  lines={[
                    { t: "ইসলামের সবচেয়ে", kind: "small", at: -5, size: 72 },
                    { t: "গুরুত্বপূর্ণ কাজ কী", kind: "gold", at: 1, size: 120 },
                  ]}
                />
              </div>
              <div style={{ position: "absolute", right: -40, top: -70, transform: `scale(${qScale}) rotate(${12 - 12 * tiltK}deg)` }}>
                <div style={{ width: 128, height: 128, borderRadius: 64, background: C.sapphire, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: "0 16px 30px -12px rgba(20,30,48,0.5)" }}>
                  <QMark size={84} color={C.champagne} p={ease(f, 0, 14, 0.2, 1)} />
                </div>
              </div>
            </div>
          </Anim>
        </Layer>

        {/* Beat 2 — "বেশিরভাগ মানুষই বলবে—" */}
        <Layer>
          <Anim at={at(10) - 2} out={262} outDur={10} type="up" cfg="hero">
            <div style={{ transform: `translateY(${-330 * lift}px) scale(${1 - 0.22 * lift})` }}>
              <KText
                lines={[
                  { t: "বেশিরভাগ মানুষই", kind: "gold", at: at(10) - 2, size: 110 },
                  { t: "বলবে—", kind: "small", at: at(12), size: 64 },
                ]}
              />
            </div>
          </Anim>
        </Layer>

        {/* Public expectation chart */}
        <Layer top={CHART_TOP}>
          <Anim at={176} out={251} outDur={1} type="up" dist={120} cfg="hero">
            <ExpectationChart headerAt={182} barAt={[at(13), at(14), at(16)]} />
          </Anim>
        </Layer>
      </CameraRig>

      <Sfx at={0} src="whoosh_open" v={0.24} />
      <Sfx at={2} src="pop_a" v={0.2} />
      <Sfx at={at(10) - 3} src="swoosh_b" v={0.18} />
      <Sfx at={at(13)} src="tick_soft" v={0.2} />
      <Sfx at={at(14)} src="tick_soft" v={0.2} />
      <Sfx at={at(16)} src="tick_soft" v={0.22} />
      <Sfx at={at(16) + 14} src="chime_spiritual" v={0.14} />
    </AbsoluteFill>
  );
};

const SpeedStreaks: React.FC<{ f: number }> = ({ f }) => {
  if (f > 34) return null;
  const rows = [
    { y: 520, c: C.gold, w: 260, d: 0 },
    { y: 590, c: C.teal, w: 180, d: 3 },
    { y: 760, c: C.sapphire, w: 220, d: 1 },
    { y: 840, c: C.gold, w: 160, d: 5 },
    { y: 900, c: C.teal, w: 240, d: 2 },
  ];
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
      {rows.map((r, i) => {
        const t = ease(f, r.d - 2, r.d + 22, 0, 1, easeOut);
        const x = i % 2 ? -300 + 1500 * t : 1380 - 1500 * t;
        return <rect key={i} x={x} y={r.y} width={r.w} height={8} rx={4} fill={r.c} opacity={0.5 * (1 - t)} />;
      })}
    </svg>
  );
};

const Sparks: React.FC<{ f: number; start: number; cx: number; cy: number; small?: boolean }> = ({ f, start, cx, cy, small }) => {
  if (f < start || f > start + 30) return null;
  const n = small ? 6 : 8;
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
      {Array.from({ length: n }).map((_, i) => {
        const a = (Math.PI * 2 * i) / n + 0.3;
        const t = ease(f, start, start + 24, 0, 1, easeOut);
        const r = (small ? 300 : 380) + 140 * t;
        return (
          <g key={i} transform={`translate(${cx + Math.cos(a) * r} ${cy + Math.sin(a) * r * 0.55}) scale(${(1 - t) * (small ? 0.5 : 0.8)})`}>
            <Star8 size={40} color={C.gold} fill={C.champagne} sw={4} />
          </g>
        );
      })}
    </svg>
  );
};
