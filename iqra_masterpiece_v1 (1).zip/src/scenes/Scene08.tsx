import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { draw, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { EdCard } from "../components/EdCard";
import { Check } from "../components/Icons";
import { KText } from "../components/KText";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(8);
const END = seqDur(8);

const TIERS = [
  { t: "পড়া ও জ্ঞান অর্জন (ইকরা)", bottom: 800, top: 660, y: 330, bg: C.teal, fs: 44, at: 172, punch: true },
  { t: "সঠিক বুঝ ও ইমান", bottom: 640, top: 500, y: 222, bg: C.sapphire, fs: 42, at: 179 },
  { t: "সঠিক আমল ও ইবাদত", bottom: 480, top: 340, y: 114, bg: C.sapphire, fs: 38, at: 182, gold: true },
];

/** Scene 8 — Foundation of knowledge: 3-tier pyramid built bottom-up. */
export const Scene08: React.FC = () => {
  const f = useCurrentFrame();
  const ring = f >= at(185) ? 0.5 + 0.5 * Math.sin((f - at(185)) * 0.2) : 0;
  return (
    <AbsoluteFill>
      <CameraRig scene={8}>
        <Layer>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 30 }}>
            <div style={{ height: 250, display: "flex", alignItems: "flex-end" }}>
              <Anim at={at(176) - 2} out={END} outDur={12} type="up" exitType="left">
                <KText lines={[{ t: "ইসলামে জ্ঞান অর্জন", kind: "small", at: at(176) - 2 }, { t: "কতটা ইম্পর্টেন্ট!", kind: "gold", at: at(178) - 2 }]} />
              </Anim>
            </div>
            <Anim at={0} out={END} outDur={12} type="fade" exitType="left">
              <EdCard w={880} h={520} pad={0}>
                <div style={{ position: "relative", width: 880, height: 520 }}>
                  {TIERS.map((t, i) => {
                    const a = at(t.at) - 2;
                    if (f < a) return null;
                    const k = sp(f, a, t.punch ? "punch" : "hero");
                    const x0 = (880 - t.bottom) / 2;
                    const x1 = (880 - t.top) / 2;
                    const isBase = i === 0;
                    return (
                      <div key={i} style={{ position: "absolute", left: 0, top: t.y + 40, width: 880, height: 104, transform: `translateY(${(1 - k) * -140}px)`, opacity: Math.min(1, k * 2) }}>
                        <svg width={880} height={104} style={{ position: "absolute", inset: 0, overflow: "visible" }}>
                          <polygon
                            points={`${x1},4 ${880 - x1},4 ${880 - x0},100 ${x0},100`}
                            fill={t.bg}
                            stroke={t.gold ? C.gold : isBase && ring ? C.gold : "none"}
                            strokeWidth={t.gold ? 5 : isBase ? 4 + ring * 4 : 0}
                            strokeLinejoin="round"
                          />
                        </svg>
                        <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: t.fs, color: C.white, whiteSpace: "nowrap" }}>{t.t}</span>
                        </div>
                      </div>
                    );
                  })}
                  {/* "first command" badge pointing to the foundation */}
                  <div style={{ position: "absolute", left: 34, top: 40 }}>
                    <Anim at={at(185) - 2} type="pop" cfg="punch">
                      <div style={{ padding: "4px 18px", borderRadius: 999, background: C.champagne, border: `2px solid ${C.gold}`, fontFamily: FONT.body, fontWeight: 700, fontSize: 28, color: C.sapphire }}>
                        প্রথম নির্দেশ = ভিত্তি
                      </div>
                    </Anim>
                  </div>
                  <div style={{ position: "absolute", right: 34, top: 34 }}>
                    <Anim at={at(189) - 2} type="pop" cfg="punch">
                      <div style={{ width: 96, height: 96, borderRadius: 48, background: "rgba(13,148,136,0.12)", border: `3px solid ${C.teal}`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                        <Check size={60} p={draw(f, at(189), 12)} />
                      </div>
                    </Anim>
                  </div>
                </div>
              </EdCard>
            </Anim>
          </div>
        </Layer>
      </CameraRig>

      <Sfx at={at(172) + 2} src="thud_heavy" v={0.22} />
      <Sfx at={at(178) - 2} src="tick_soft" v={0.18} />
      <Sfx at={at(179) - 2} src="pop_a" v={0.18} />
      <Sfx at={at(182) - 2} src="pop_b" v={0.18} />
      <Sfx at={at(189) - 2} src="confirm" v={0.15} />
      <Sfx at={END - 13} src="swoosh_a" v={0.16} />
    </AbsoluteFill>
  );
};
