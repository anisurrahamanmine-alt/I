import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { draw, ease, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { BlindFigure } from "../components/Characters";
import { Chip, EdCard } from "../components/EdCard";
import { BookOpen, Check, Cross } from "../components/Icons";
import { KText } from "../components/KText";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(9);
const END = seqDur(9);

/** Scene 9 — Blind faith vs true knowledge: split comparison card. */
export const Scene09: React.FC = () => {
  const f = useCurrentFrame();
  const stamp = sp(f, at(199) - 2, "punch");
  const bookOpen = ease(f, at(202), at(202) + 16, 0, 1, easeOut);
  return (
    <AbsoluteFill>
      <CameraRig scene={9}>
        <Layer>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 34 }}>
            <Anim at={at(191) - 6} type="left" dist={220} cfg="hero">
              <EdCard w={880} h={600} pad={0} style={{ overflow: "hidden" }}>
                <div style={{ display: "flex", height: "100%" }}>
                  {/* Left — blind acceptance */}
                  <div style={{ flex: 1, background: "rgba(190,18,60,0.06)", borderTop: `8px solid ${C.ruby}`, borderRadius: "20px 0 0 20px", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 30 }}>
                    <Anim at={at(193) - 4} type="up">
                      <BlindFigure at={at(193)} size={220} />
                    </Anim>
                    <div style={{ position: "absolute", top: 400 }}>
                      <Anim at={at(196) - 2} type="up">
                        <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 56, color: C.ruby, lineHeight: 1.2 }}>অন্ধভাবে মানা</span>
                      </Anim>
                    </div>
                    {f >= at(199) - 2 ? (
                      <div style={{ position: "absolute", top: 482, display: "flex", alignItems: "center", gap: 10, padding: "4px 22px", border: `4px solid ${C.ruby}`, borderRadius: 14, background: C.ivory, transform: `rotate(-7deg) scale(${2 - stamp})`, opacity: Math.min(1, stamp * 1.5) }}>
                        <Cross size={44} sw={13} p={draw(f, at(199), 8)} />
                        <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 46, color: C.ruby }}>ধর্ম নয়</span>
                      </div>
                    ) : null}
                  </div>
                  <div style={{ width: 2, background: C.hairline }} />
                  {/* Right — read and know */}
                  <div style={{ flex: 1, background: `rgba(13,148,136,${0.05 + 0.06 * bookOpen})`, borderTop: `8px solid ${C.teal}`, borderRadius: "0 20px 20px 0", position: "relative", display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 70 }}>
                    <Anim at={at(202) - 4} type="pop" cfg="hero">
                      <div style={{ filter: `drop-shadow(0 0 ${30 * bookOpen}px rgba(253,230,138,0.9))` }}>
                        <BookOpen size={250} color={C.teal} sw={4} open={bookOpen} fill={C.ivory} p={draw(f, at(202) - 4, 18)} />
                      </div>
                    </Anim>
                    <div style={{ position: "absolute", top: 400 }}>
                      <Anim at={at(205) - 2} type="up">
                        <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 56, color: C.teal, lineHeight: 1.2 }}>পড়ো ও জানো</span>
                      </Anim>
                    </div>
                    <div style={{ position: "absolute", top: 480 }}>
                      <Anim at={at(206)} type="pop" cfg="punch">
                        <div style={{ width: 84, height: 84, borderRadius: 42, background: C.teal, display: "flex", alignItems: "center", justifyContent: "center" }}>
                          <Check size={54} color={C.white} p={draw(f, at(206) + 2, 10)} />
                        </div>
                      </Anim>
                    </div>
                  </div>
                </div>
                {/* "বনাম" divider chip */}
                <div style={{ position: "absolute", left: 440 - 56, top: 24 }}>
                  <Anim at={at(191)} type="pop" cfg="hero">
                    <div style={{ width: 112, height: 112, borderRadius: 56, background: C.sapphire, border: `3px solid ${C.gold}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: FONT.body, fontWeight: 700, fontSize: 34, color: C.champagne }}>
                      বনাম
                    </div>
                  </Anim>
                </div>
              </EdCard>
            </Anim>

            {/* Below the card: ignorance tag swiped away, then the closing line */}
            <div style={{ height: 250, position: "relative", width: 880, display: "flex", justifyContent: "center" }}>
              <div style={{ position: "absolute", top: 40 }}>
                <Anim at={at(208)} out={at(210) + 2} outDur={10} type="pop" exitType="right" cfg="punch">
                  <Chip style={{ background: C.ruby, border: `2px solid ${C.ruby}` }}>
                    <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 64, color: C.white, lineHeight: 1.2 }}>অজ্ঞতা</span>
                  </Chip>
                </Anim>
              </div>
              <div style={{ position: "absolute", top: 0 }}>
                <Anim at={at(210)} type="up">
                  <KText lines={[{ t: "সেই ইসলামে", kind: "small", at: at(210) }, { t: "অজ্ঞতার জায়গা নেই!", kind: "ruby", at: at(211) - 4, size: 96 }]} />
                </Anim>
              </div>
            </div>
          </div>
        </Layer>
      </CameraRig>

      <Sfx at={at(191) - 6} src="paper_slide" v={0.22} />
      <Sfx at={at(199)} src="stamp_thud" v={0.2} />
      <Sfx at={at(206)} src="chime_spiritual" v={0.17} />
      <Sfx at={at(208)} src="pop_a" v={0.18} />
      <Sfx at={at(210) - 6} src="swoosh_b" v={0.16} />
      <Sfx at={END - 16} src="zoom_through" v={0.18} />
    </AbsoluteFill>
  );
};
