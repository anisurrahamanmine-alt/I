import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { draw, ease, easeIn, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { EdCard } from "../components/EdCard";
import { BookClosed, Crescent, PauseIcon, Person, ScrollSeal } from "../components/Icons";
import { KText } from "../components/KText";
import { TopLight } from "../components/Light";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(5);
const END = seqDur(5);

type PillDef = {
  pre: string;
  key: string;
  Icon: React.FC<{ size?: number; color?: string; p?: number }>;
  color: string;
  slotAt?: number;
  fillAt: number;
  pulseAt: number;
  lockAt: number;
};

const PILLS: PillDef[] = [
  { pre: "জীবনব্যবস্থার নাম:", key: "ইসলাম", Icon: Crescent, color: C.teal, fillAt: at(95) - 2, pulseAt: at(97), lockAt: at(98) },
  { pre: "তোমাদের পরিচয়:", key: "মুসলিম", Icon: Person, color: C.sapphire, fillAt: at(99) - 2, pulseAt: at(100), lockAt: at(101) },
  { pre: "নবুয়তের", key: "ঘোষণা", Icon: ScrollSeal, color: C.gold, slotAt: at(102), fillAt: at(109), pulseAt: at(112), lockAt: at(113) },
  { pre: "কোরআনের", key: "পরিচয়", Icon: BookClosed, color: C.sapphire, fillAt: at(114) - 2, pulseAt: at(118), lockAt: at(119) },
];

/** Scene 5 — Before any identity was introduced: cumulative identity-pause checklist. */
export const Scene05: React.FC = () => {
  const f = useCurrentFrame();
  const dimStart = at(120);
  const dimK = ease(f, dimStart, dimStart + 14, 0, 1);
  const slide = ease(f, at(123) - 4, at(123) + 14, 0, 1, easeIn);
  const swell = ease(f, END - 50, END, 0, 0.6);
  const exitUp = ease(f, END - 14, END, 0, 1, easeIn);

  return (
    <AbsoluteFill>
      <TopLight k={swell} />
      <CameraRig scene={5}>
        <div style={{ position: "absolute", inset: 0, transform: `translateY(${-120 * exitUp}px)`, opacity: 1 - exitUp }}>
          {f < at(123) + 16 ? (
            <Layer>
              <div
                style={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 28,
                  opacity: 1 - dimK * 0.75 - slide * 0.25,
                  filter: dimK > 0.02 ? `blur(${dimK * 2.5}px)` : undefined,
                  transform: `translateY(${slide * 260}px) scale(${1 - 0.08 * dimK})`,
                }}
              >
                <Anim at={at(88)} type="up">
                  <KText lines={[{ t: "আল্লাহ তখন এটাও", kind: "small", at: at(88) }, { t: "বলেননি", kind: "ruby", at: at(91) - 2, size: 96 }]} />
                </Anim>
                <Anim at={at(87) + 2} type="left" dist={240} cfg="hero">
                  <EdCard w={880} pad={34}>
                    <div style={{ display: "flex", alignItems: "center", gap: 14, marginBottom: 18 }}>
                      <PauseIcon size={48} color={C.gold} p={draw(f, at(87) + 10, 20)} />
                      <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 46, color: C.sapphire }}>পরিচয় দেওয়ারও আগে...</span>
                    </div>
                    <div style={{ height: 2, background: C.hairline, marginBottom: 18 }} />
                    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                      {PILLS.map((p, i) => (
                        <IdentityPill key={i} p={p} f={f} />
                      ))}
                    </div>
                  </EdCard>
                </Anim>
              </div>
            </Layer>
          ) : null}

          {/* Final line once the checklist dims away */}
          <Layer>
            <Anim at={at(123) - 2} type="up" cfg="hero">
              <KText lines={[{ t: "এসব কোনো পরিচয়", kind: "small", at: at(123) - 2 }, { t: "দেওয়ারও আগে...", kind: "gold", at: at(124) - 2, size: 112 }]} />
            </Anim>
          </Layer>
        </div>
      </CameraRig>

      <Sfx at={at(87) + 2} src="paper_slide" v={0.22} />
      <Sfx at={PILLS[0].lockAt} src="type_tick" v={0.2} />
      <Sfx at={PILLS[1].lockAt} src="type_tick" v={0.2} />
      <Sfx at={PILLS[2].lockAt} src="type_tick" v={0.2} />
      <Sfx at={PILLS[3].lockAt} src="type_tick" v={0.2} />
      <Sfx at={dimStart} src="paper_rustle" v={0.24} />
      <Sfx at={END - 50} src="swell_warm" v={0.16} />
    </AbsoluteFill>
  );
};

const IdentityPill: React.FC<{ p: PillDef; f: number }> = ({ p, f }) => {
  const h = 118;
  const start = p.slotAt ?? p.fillAt;
  if (f < start) return <div style={{ height: h, borderRadius: 999, border: `2px dashed ${C.hairline}` }} />;
  const k = sp(f, start, "hero");
  const filled = f >= p.fillAt;
  const fk = sp(f, p.fillAt, "soft");
  const lock = sp(f, p.lockAt, "punch");
  const locked = f >= p.lockAt;
  const pulse = f >= p.pulseAt && f < p.pulseAt + 18 ? Math.sin(((f - p.pulseAt) / 18) * Math.PI) * 0.08 : 0;
  return (
    <div
      style={{
        position: "relative",
        height: h,
        borderRadius: 999,
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "0 20px",
        background: filled ? "#FFFDF5" : "transparent",
        border: filled ? `2.5px solid ${locked ? C.gold : C.hairline}` : `2.5px dashed ${C.gold}`,
        boxShadow: filled ? "0 10px 22px -16px rgba(20,30,48,0.4)" : undefined,
        transform: `translateX(${(1 - k) * 80}px)`,
        opacity: Math.min(1, k * 1.5),
      }}
    >
      <div style={{ width: 76, height: 76, borderRadius: 38, background: "rgba(20,30,48,0.05)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        <p.Icon size={52} color={p.color} p={draw(f, start, 22)} />
      </div>
      {filled ? (
        <div style={{ display: "flex", alignItems: "baseline", gap: 12, opacity: Math.min(1, fk * 1.5), transform: `translateY(${(1 - fk) * 12}px)` }}>
          <span style={{ fontFamily: FONT.body, fontWeight: 600, fontSize: 36, color: C.slate, whiteSpace: "nowrap" }}>{p.pre}</span>
          <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 52, color: C.sapphire, whiteSpace: "nowrap", display: "inline-block", transform: `scale(${1 + pulse})` }}>{p.key}</span>
        </div>
      ) : null}
      {locked ? (
        <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 10, transform: `scale(${lock})` }}>
          <div style={{ transform: "rotate(-6deg)", border: `3px solid ${C.ruby}`, borderRadius: 10, padding: "0 10px", whiteSpace: "nowrap", fontFamily: FONT.body, fontWeight: 700, fontSize: 26, color: C.ruby, background: C.ivory }}>
            এখনো নয়
          </div>
          <PauseIcon size={40} color={C.gold} sw={7} />
        </div>
      ) : null}
    </div>
  );
};

