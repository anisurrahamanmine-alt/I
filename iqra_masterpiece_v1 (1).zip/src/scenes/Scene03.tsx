import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { draw, ease, easeIn, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { Chip } from "../components/EdCard";
import { Cross, Mosque, Shield } from "../components/Icons";
import { KText } from "../components/KText";
import { Dust, Flash, TopLight } from "../components/Light";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(3);
const END = seqDur(3);

/** Scene 3 — Clear the stage, build tension, SOLO climax: اقْرَأْ / ইকরা / পড়ো! (lit from above). */
export const Scene03: React.FC = () => {
  const f = useCurrentFrame();
  const climax = at(56) - 2;
  const veil = ease(f, at(48), at(48) + 30, 0, 0.55);
  const light = ease(f, at(48), climax, 0.15, 0.55) + ease(f, climax, climax + 10, 0, 0.35);
  const flash = f >= climax ? Math.exp(-(f - climax) / 6) : 0;

  // Handoff: the climax lock-up shrinks into a header anchor for Scene 4
  const hand = ease(f, END - 16, END, 0, 1, easeIn);

  return (
    <AbsoluteFill>
      <AbsoluteFill style={{ background: "rgba(255,254,250,1)", opacity: veil }} />
      <TopLight k={light} floorY={1180} width={460} />
      <CameraRig scene={3} fg={<Dust k={ease(f, climax, climax + 20, 0, 1)} y0={180} y1={1150} spread={300} n={26} />}>
        {/* Two chips crossed out, then swiped away */}
        <Layer>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 70 }}>
            <Anim at={at(38) + 1} out={at(48) - 2} outDur={10} type="pop" exitType="left" cfg="hero">
              <StruckChip text="কোনো ইবাদত" icon={<Mosque size={66} color={C.sapphire} />} strikeAt={at(41) + 6} />
            </Anim>
            <Anim at={at(43)} out={at(48) + 2} outDur={10} type="pop" exitType="left" cfg="hero">
              <StruckChip text="কোনো কঠিন নিয়ম" icon={<Shield size={64} color={C.sapphire} />} strikeAt={at(47)} />
            </Anim>
          </div>
        </Layer>

        {/* Tension line */}
        <Layer>
          <Anim at={at(48) + 2} out={climax - 2} outDur={10} type="up" exitType="zoom">
            <KText lines={[{ t: "আল্লাহর তরফ থেকে আসা", kind: "small", at: at(48) + 2 }, { t: "একদম প্রথম ওয়ার্ড", kind: "gold", at: at(52) }]} />
          </Anim>
        </Layer>

        {/* SOLO CLIMAX */}
        <Layer>
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              transform: `translateY(${-560 * hand}px) scale(${1 - 0.7 * hand})`,
              opacity: 1 - hand * 0.6,
            }}
          >
            <ArabicIqra f={f} start={climax} />
            <Anim at={climax + 4} type="pop" cfg="hero">
              <div
                style={{
                  fontFamily: FONT.hero,
                  fontWeight: 800,
                  fontSize: 185,
                  lineHeight: 1.12,
                  color: C.teal,
                  paddingTop: 12,
                  textShadow: "0 18px 40px rgba(13,148,136,0.25)",
                }}
              >
                ইকরা
              </div>
            </Anim>
            <div style={{ height: 6 }} />
            <Anim at={at(58) - 2} type="drop" cfg="punch">
              <KText lines={[{ t: "পড়ো!", kind: "gold", at: at(58) - 2, size: 160, underline: true }]} />
            </Anim>
          </div>
        </Layer>
      </CameraRig>
      <Flash k={flash} />

      <Sfx at={at(38) + 1} src="pop_a" v={0.2} />
      <Sfx at={at(41) + 6} src="slash" v={0.2} />
      <Sfx at={at(47)} src="slash" v={0.2} />
      <Sfx at={at(48) - 4} src="swoosh_a" v={0.17} />
      <Sfx at={climax - 100} src="riser_low" v={0.12} />
      <Sfx at={climax} src="boom_deep" v={0.24} />
      <Sfx at={climax + 2} src="chime_deep" v={0.2} />
    </AbsoluteFill>
  );
};

const StruckChip: React.FC<{ text: string; icon: React.ReactNode; strikeAt: number }> = ({ text, icon, strikeAt }) => {
  const f = useCurrentFrame();
  const p = draw(f, strikeAt, 9);
  const dim = ease(f, strikeAt + 3, strikeAt + 12, 1, 0.55);
  return (
    <div style={{ position: "relative" }}>
      <Chip style={{ padding: "22px 46px" }}>
        <div style={{ opacity: dim }}>{icon}</div>
        <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 64, color: C.sapphire, opacity: dim }}>{text}</span>
      </Chip>
      {f >= strikeAt ? (
        <>
          <svg width="110%" height={60} viewBox="0 0 100 60" preserveAspectRatio="none" style={{ position: "absolute", left: "-5%", top: "30%", overflow: "visible" }}>
            <path d="M2 46 Q50 22 98 14" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} fill="none" stroke={C.ruby} strokeWidth={10} strokeLinecap="round" vectorEffect="non-scaling-stroke" />
          </svg>
          <div style={{ position: "absolute", right: -46, top: -40, transform: `scale(${sp(f, strikeAt, "punch")})` }}>
            <div style={{ width: 92, height: 92, borderRadius: 46, background: C.ivory, boxShadow: "0 10px 24px -10px rgba(190,18,60,0.5)", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <Cross size={58} p={p} sw={12} />
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
};

const ArabicIqra: React.FC<{ f: number; start: number }> = ({ f, start }) => {
  if (f < start - 2) return <div style={{ height: 250 }} />;
  const rev = ease(f, start - 2, start + 22, 0, 1, easeOut);
  const k = sp(f, start - 2, "slow");
  const glow = 0.5 + 0.2 * Math.sin((f - start) * 0.08);
  return (
    <div
      dir="rtl"
      lang="ar"
      style={{
        unicodeBidi: "embed",
        direction: "rtl",
        fontFamily: "'AmiriQuran', 'ScheherazadeNew', serif",
        fontSize: 200,
        lineHeight: 1.25,
        height: 250,
        color: C.sapphire,
        clipPath: `inset(-20% 0 -20% ${100 - rev * 100}%)`,
        transform: `scale(${0.9 + 0.1 * k})`,
        textShadow: `0 0 40px rgba(253,230,138,${glow}), 0 0 90px rgba(253,230,138,${glow * 0.6})`,
      }}
    >
      اقْرَأْ
    </div>
  );
};
