import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { ease, easeOut, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { EdCard } from "../components/EdCard";
import { BellIc, Cursor, Heart, ShareIc, Star8 } from "../components/Icons";
import { KText } from "../components/KText";
import { C, FONT, SHADOW } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(11);
const END = seqDur(11);

/** Scene 11 — The ONLY full-screen background: serene dawn sky to the very bottom; clean CTA + lock-up. */
export const Scene11: React.FC = () => {
  const f = useCurrentFrame();
  const sky = ease(f, 0, 24, 0, 1);
  const tapAt = at(241);
  const tap = f < tapAt ? 1 : f < tapAt + 4 ? 1 - 0.1 * ((f - tapAt) / 4) : 0.9 + 0.18 * sp(f, tapAt + 4, "punch") - 0.08 * ease(f, tapAt + 10, tapAt + 22, 0, 1);
  const curIn = sp(f, at(239) + 2, "soft");
  const curX = 760 - 70 * ease(f, at(239) + 2, tapAt - 2, 0, 1, easeOut);
  const curY = 300 - 250 * ease(f, at(239) + 2, tapAt - 2, 0, 1, easeOut);
  const ripple = f >= tapAt ? ease(f, tapAt, tapAt + 24, 0, 1, easeOut) : 0;
  const sweep = ease(f, at(236), at(236) + 30, -0.3, 1.3);

  return (
    <AbsoluteFill>
      <DawnSky k={sky} f={f} />
      <CameraRig scene={11}>
        {/* Top-centre hero card */}
        <Layer top={180}>
          <Anim at={at(227) - 4} type="up" dist={90} cfg="hero">
            <EdCard w={820} pad={34} ornate>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 2 }}>
                <div dir="rtl" lang="ar" style={{ unicodeBidi: "embed", fontFamily: "'AmiriQuran', 'ScheherazadeNew', serif", fontSize: 120, lineHeight: 1.3, color: C.sapphire, textShadow: "0 0 30px rgba(253,230,138,0.8)" }}>
                  اقْرَأْ
                </div>
                <KText lines={[{ t: "ইকরা — পড়ো", kind: "teal", at: at(227) + 6, size: 84 }]} />
                <div style={{ height: 2, width: 420, background: C.gold, opacity: 0.6, margin: "12px 0" }} />
                <KText
                  gap={4}
                  lines={[
                    { t: "ইসলামের সর্বপ্রথম নির্দেশ", kind: "small", at: at(229), size: 46, serif: true },
                    { t: "জ্ঞানের আলোয় আলোকিত হোন", kind: "small", at: at(232), size: 46, serif: true },
                  ]}
                />
              </div>
            </EdCard>
          </Anim>
        </Layer>

        {/* CTA action bar */}
        <Layer top={810}>
          <Anim at={at(236) - 6} type="up" cfg="hero">
            <div style={{ position: "relative", width: 860, padding: 18, boxSizing: "border-box", borderRadius: 999, background: C.ivory, border: `3px solid ${C.teal}`, boxShadow: SHADOW, display: "flex", justifyContent: "space-between", alignItems: "center", overflow: "hidden" }}>
              <div style={{ position: "absolute", top: 0, bottom: 0, width: 140, left: `${sweep * 100}%`, background: "linear-gradient(100deg, transparent, rgba(253,230,138,0.7), transparent)", transform: "skewX(-20deg)" }} />
              <CtaPill f={f} at={at(236) - 2} icon={<Heart size={46} color={C.ruby} />} label="লাইক" />
              <CtaPill f={f} at={at(237) - 2} icon={<ShareIc size={46} color={C.teal} />} label="শেয়ার" />
              <div style={{ transform: `scale(${tap})` }}>
                <CtaPill f={f} at={at(239) - 2} icon={<BellIc size={44} color={C.white} />} label="সাবস্ক্রাইব / ফলো" filled />
              </div>
            </div>
          </Anim>
          {ripple > 0 && ripple < 1 ? (
            <div style={{ position: "absolute", left: 690 - 130 * ripple, top: 62 - 130 * ripple, width: 260 * ripple, height: 260 * ripple, borderRadius: "50%", border: `4px solid ${C.champagne}`, opacity: 1 - ripple }} />
          ) : null}
          {f >= at(239) + 2 ? (
            <div style={{ position: "absolute", left: curX, top: curY, opacity: Math.min(1, curIn * 1.5) * (1 - ease(f, tapAt + 30, tapAt + 42, 0, 1)), transform: `scale(${f >= tapAt && f < tapAt + 6 ? 0.88 : 1})` }}>
              <Cursor size={84} />
            </div>
          ) : null}
        </Layer>

        {/* Final lock-up */}
        <Layer top={1020}>
          <Anim at={at(243) - 2} type="pop" cfg="hero">
            <KText backing lines={[{ t: "সাথেই থাকুন!", kind: "teal", at: at(243) - 2, size: 112, underline: true }]} />
          </Anim>
        </Layer>
      </CameraRig>

      <Sfx at={0} src="swell_warm" v={0.16} />
      <Sfx at={at(236) - 6} src="pop_soft" v={0.18} />
      <Sfx at={at(236)} src="shimmer" v={0.12} />
      <Sfx at={tapAt} src="ui_click" v={0.25} />
      <Sfx at={tapAt + 1} src="ripple" v={0.16} />
      <Sfx at={at(243)} src="chime_spiritual" v={0.18} dur={END - at(243)} />
    </AbsoluteFill>
  );
};

const CtaPill: React.FC<{ f: number; at: number; icon: React.ReactNode; label: string; filled?: boolean }> = ({ f, at: a, icon, label, filled }) => {
  const k = f >= a ? sp(f, a, "punch") : 0;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: "16px 28px",
        borderRadius: 999,
        background: filled ? C.teal : "rgba(20,30,48,0.04)",
        border: filled ? `2px solid ${C.teal}` : `2px solid ${C.hairline}`,
        transform: `scale(${0.85 + 0.15 * k})`,
        opacity: 0.5 + 0.5 * Math.min(1, k * 1.4),
        position: "relative",
      }}
    >
      {icon}
      <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 40, color: filled ? C.white : C.sapphire, whiteSpace: "nowrap" }}>{label}</span>
    </div>
  );
};

const DawnSky: React.FC<{ k: number; f: number }> = ({ k, f }) => (
  <AbsoluteFill style={{ opacity: k }}>
    <AbsoluteFill style={{ background: "linear-gradient(180deg, #141E30 0%, #16304A 28%, #0F5E64 55%, #2F8F86 70%, #E9D196 88%, #FDE68A 100%)" }} />
    <AbsoluteFill style={{ background: `radial-gradient(ellipse 70% 30% at 50% ${104 - k * 4}%, rgba(253,230,138,0.85), transparent 70%)` }} />
    <svg width={1080} height={1920} style={{ position: "absolute", inset: 0 }}>
      {Array.from({ length: 26 }).map((_, i) => {
        const x = (i * 263) % 1040 + 20;
        const y = (i * 137) % 900 + 40 + Math.sin(f * 0.01 + i) * 6;
        const tw = 0.3 + 0.6 * Math.sin(f * 0.06 + i * 1.7) ** 2;
        return (
          <g key={i} transform={`translate(${x} ${y}) scale(${0.25 + (i % 4) * 0.08})`} opacity={tw}>
            <Star8 size={60} color={C.champagne} fill={i % 3 === 0 ? C.champagne : undefined} sw={6} />
          </g>
        );
      })}
      <g opacity={0.12} transform={`rotate(${f * 0.03} 540 1920)`}>
        <circle cx={540} cy={1920} r={520} fill="none" stroke={C.champagne} strokeWidth={2} />
        <circle cx={540} cy={1920} r={640} fill="none" stroke={C.champagne} strokeWidth={1.5} strokeDasharray="4 12" />
        <circle cx={540} cy={1920} r={780} fill="none" stroke={C.champagne} strokeWidth={1} />
      </g>
    </svg>
  </AbsoluteFill>
);
