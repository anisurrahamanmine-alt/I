import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { draw, sp } from "../anim";
import { Anim, Sfx } from "../components/Anim";
import { CameraRig, Layer } from "../components/CameraRig";
import { Thinker } from "../components/Characters";
import { Chip, EdCard } from "../components/EdCard";
import { CharityHand, Crescent, Mosque, Shield } from "../components/Icons";
import { KText } from "../components/KText";
import { C, FONT } from "../config";
import { localAt, seqDur } from "../timeline";

const at = localAt(4);
const END = seqDur(4);

/** Header anchor carried over from the Scene 3 climax. */
export const IqraAnchor: React.FC<{ label?: string }> = ({ label = "ইকরা — পড়ো" }) => (
  <Chip style={{ padding: "12px 30px", gap: 16, borderColor: "rgba(217,119,6,0.45)" }}>
    <span dir="rtl" lang="ar" style={{ unicodeBidi: "embed", fontFamily: "'AmiriQuran', 'ScheherazadeNew', serif", fontSize: 48, color: C.sapphire, lineHeight: 1.3 }}>
      اقْرَأْ
    </span>
    <span style={{ width: 2, height: 40, background: C.gold, opacity: 0.6 }} />
    <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 40, color: C.teal }}>{label}</span>
  </Chip>
);

const CELLS = [
  { t: "নামাজ পড়ো", Icon: Mosque, c: C.sapphire, w: 72 },
  { t: "রোজা রাখো", Icon: Crescent, c: C.teal, w: 74 },
  { t: "যাকাত দাও", Icon: CharityHand, c: C.gold, w: 76 },
  { t: "গুনাহ থেকে দূরে থাকো", Icon: Shield, c: C.ruby, w: 81 },
];

/** Scene 4 — Pause & reflect: thinker micro-acting, then the 2x2 "what could have been first" grid. */
export const Scene04: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <CameraRig scene={4}>
        <Layer top={190}>
          <Anim at={-4} out={at(65) + 6} outDur={12} type="down" dist={30} exitType="up">
            <IqraAnchor />
          </Anim>
        </Layer>

        {/* Thinker + question */}
        <Layer>
          <Anim at={at(59)} out={at(64) + 12} outDur={12} type="up" exitType="left">
            <div style={{ display: "flex", alignItems: "center", gap: 10, maxWidth: 900 }}>
              <Thinker at={at(59)} chinAt={at(61)} tiltAt={at(63)} size={400} />
              <KText align="left" maxW={520} lines={[{ t: "একটু ভাবতে", kind: "small", at: at(60), size: 62 }, { t: "পারছেন", kind: "small", at: at(62), size: 62 }, { t: "বিষয়টা?", kind: "gold", at: at(63) - 2, size: 120 }]} />
            </div>
          </Anim>
        </Layer>

        {/* 2x2 possibility grid */}
        <Layer>
          <Anim at={at(65)} out={END} outDur={12} type="up" exitType="left">
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 26 }}>
              <KText lines={[{ t: "আল্লাহ তো চাইলে প্রথমেই", kind: "small", at: at(65) }, { t: "বলতে পারতেন", kind: "gold", at: at(69), size: 96 }]} />
              <Anim at={at(71) - 4} type="up" dist={60}>
                <EdCard w={880} pad={26}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
                    {CELLS.map((c, i) => (
                      <Cell key={i} {...c} start={at(c.w) - 3} f={f} />
                    ))}
                  </div>
                </EdCard>
              </Anim>
              <div style={{ height: 70 }}>
                <Anim at={at(85) - 2} type="pop" cfg="punch">
                  <Chip style={{ background: C.sapphire, border: `2px solid ${C.gold}`, padding: "10px 36px" }}>
                    <span style={{ fontFamily: FONT.hero, fontWeight: 800, fontSize: 54, color: C.champagne, lineHeight: 1.2 }}>তাই না?</span>
                  </Chip>
                </Anim>
              </div>
            </div>
          </Anim>
        </Layer>
      </CameraRig>

      <Sfx at={at(59) + 2} src="pop_soft" v={0.18} />
      <Sfx at={at(72) - 3} src="pop_a" v={0.18} />
      <Sfx at={at(74) - 3} src="pop_b" v={0.18} />
      <Sfx at={at(76) - 3} src="pop_a" v={0.18} />
      <Sfx at={at(81) - 3} src="pop_b" v={0.18} />
      <Sfx at={at(85) - 2} src="ding_bright" v={0.13} />
      <Sfx at={END - 13} src="swoosh_c" v={0.17} />
    </AbsoluteFill>
  );
};

const Cell: React.FC<{ t: string; Icon: React.FC<{ size?: number; color?: string; p?: number }>; c: string; start: number; f: number }> = ({ t, Icon, c, start, f }) => {
  if (f < start) return <div style={{ height: 200, borderRadius: 18, border: `2px dashed ${C.hairline}` }} />;
  const k = sp(f, start, "hero");
  return (
    <div
      style={{
        height: 200,
        borderRadius: 18,
        background: "#FFFDF6",
        border: `2px solid ${C.hairline}`,
        borderTop: `6px solid ${c}`,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 10,
        transform: `scale(${0.6 + 0.4 * k})`,
        opacity: Math.min(1, k * 1.5),
      }}
    >
      <Icon size={74} color={c} p={draw(f, start, 16)} />
      <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: t.length > 12 ? 38 : 48, color: C.sapphire, textAlign: "center", lineHeight: 1.2 }}>{t}</span>
    </div>
  );
};
