import React from "react";
import { useCurrentFrame } from "remotion";
import { draw, ease, easeOut, sp } from "../anim";
import { C, FONT } from "../config";
import { EdCard } from "./EdCard";
import { CharityHand, Crescent, Cross, Mosque, Person } from "./Icons";

export const CHART_TOP = 630;

const ROWS = [
  { label: "নামাজ", color: C.sapphire, tint: "rgba(20,30,48,0.07)", Icon: Mosque, len: 0.92 },
  { label: "রোজা", color: C.teal, tint: "rgba(13,148,136,0.09)", Icon: Crescent, len: 0.8 },
  { label: "যাকাত", color: C.gold, tint: "rgba(217,119,6,0.1)", Icon: CharityHand, len: 0.7 },
];

/** "মানুষ যা ভাবে" 3-bar expectation diagram (shared by Scene 1 and Scene 2 for a seamless handoff). */
export const ExpectationChart: React.FC<{ barAt: number[]; headerAt: number; strikeAt?: number[] }> = ({ barAt, headerAt, strikeAt }) => {
  const f = useCurrentFrame();
  return (
    <EdCard w={860} pad={44}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 26 }}>
        <span style={{ fontFamily: FONT.body, fontWeight: 700, fontSize: 44, color: C.sapphire, opacity: Math.min(1, sp(f, headerAt) * 1.4) }}>
          মানুষ যা ভাবে
        </span>
        <div style={{ display: "flex", gap: 6 }}>
          {[0, 1, 2, 3, 4].map((i) => {
            const k = sp(f, headerAt + 4 + i * 3, "hero");
            return (
              <div key={i} style={{ transform: `translateY(${(1 - k) * 20}px) scale(${k})`, opacity: k }}>
                <Person size={40} color={i % 2 ? C.teal : C.sapphire} />
              </div>
            );
          })}
        </div>
      </div>
      <div style={{ height: 2, background: C.hairline, marginBottom: 22 }} />
      {ROWS.map((r, i) => {
        const a = barAt[i];
        const k = sp(f, a - 6, "hero");
        const bar = ease(f, a, a + 22, 0, r.len, easeOut);
        const s = strikeAt ? draw(f, strikeAt[i], 10) : 0;
        const fade = strikeAt ? ease(f, strikeAt[i] + 4, strikeAt[i] + 14, 1, 0.45) : 1;
        if (f < a - 6) return <div key={i} style={{ height: 118 }} />;
        return (
          <div key={i} style={{ position: "relative", height: 118, display: "flex", alignItems: "center", gap: 24, opacity: Math.min(1, k * 1.4), transform: `translateX(${(1 - k) * -40}px)` }}>
            <div style={{ width: 92, height: 92, borderRadius: 26, background: r.tint, display: "flex", alignItems: "center", justifyContent: "center", opacity: fade }}>
              <r.Icon size={62} color={r.color} p={draw(f, a - 4, 18)} />
            </div>
            <span style={{ width: 170, fontFamily: FONT.body, fontWeight: 700, fontSize: 54, color: C.sapphire, opacity: fade }}>{r.label}</span>
            <div style={{ flex: 1, height: 36, borderRadius: 18, background: "#F1EEE6", overflow: "hidden", opacity: fade }}>
              <div style={{ width: `${bar * 100}%`, height: "100%", borderRadius: 18, background: r.color }} />
            </div>
            {strikeAt && f >= strikeAt[i] ? (
              <>
                <svg width={720} height={118} viewBox="0 0 720 118" style={{ position: "absolute", left: 0, top: 0, overflow: "visible" }}>
                  <path d="M4 70 Q360 44 716 52" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - s} fill="none" stroke={C.ruby} strokeWidth={9} strokeLinecap="round" />
                </svg>
                <div style={{ position: "absolute", right: -10, top: 14, transform: `scale(${0.6 + 0.4 * sp(f, strikeAt[i], "punch")})` }}>
                  <Cross size={86} p={draw(f, strikeAt[i], 10)} />
                </div>
              </>
            ) : null}
          </div>
        );
      })}
    </EdCard>
  );
};
