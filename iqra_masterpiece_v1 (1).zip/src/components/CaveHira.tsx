import React from "react";
import { useCurrentFrame } from "remotion";
import { ease } from "../anim";
import { C } from "../config";

/**
 * Editorial ink-and-gouache style illustration: Jabal al-Nour and the empty rocky arch of Cave Hira,
 * bathed in a top-down beam of warm champagne light. No figures (Rule 14).
 */
export const CaveHira: React.FC<{ w: number; h: number; lightAt: number }> = ({ w, h, lightAt }) => {
  const f = useCurrentFrame();
  const L = ease(f, lightAt, lightAt + 40, 0, 1);
  const drift = Math.sin(f * 0.02) * 6;
  return (
    <svg width={w} height={h} viewBox="0 0 860 520" preserveAspectRatio="xMidYMid slice">
      <defs>
        <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#1B2A45" />
          <stop offset="0.6" stopColor="#2F5468" />
          <stop offset="1" stopColor="#D9C089" />
        </linearGradient>
        <linearGradient id="beam" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={C.champagne} stopOpacity={0.85} />
          <stop offset="1" stopColor={C.champagne} stopOpacity={0.05} />
        </linearGradient>
        <filter id="gouache">
          <feTurbulence type="fractalNoise" baseFrequency="0.035" numOctaves="3" seed="4" />
          <feDisplacementMap in="SourceGraphic" scale="7" />
        </filter>
        <filter id="blurB">
          <feGaussianBlur stdDeviation="14" />
        </filter>
        <radialGradient id="caveIn" cx="0.5" cy="0.6" r="0.6">
          <stop offset="0" stopColor="#3A2E1F" />
          <stop offset="1" stopColor="#120D08" />
        </radialGradient>
      </defs>
      <rect width={860} height={520} fill="url(#sky)" />
      {/* stars */}
      {Array.from({ length: 18 }).map((_, i) => (
        <circle key={i} cx={(i * 197) % 860} cy={(i * 71) % 200 + 20} r={1.4 + (i % 3) * 0.6} fill={C.champagne} opacity={0.35 + 0.35 * Math.sin(f * 0.06 + i) ** 2} />
      ))}
      {/* far ridges */}
      <path filter="url(#gouache)" d={`M0 330 Q120 ${260 + drift} 230 300 T470 270 T700 290 T860 260 V520 H0 Z`} fill="#4E6E78" opacity={0.85} />
      {/* Jabal al-Nour main mass */}
      <path filter="url(#gouache)" d="M70 520 L230 250 Q300 150 380 130 Q440 118 500 160 L610 270 L800 520 Z" fill="#6B5139" />
      <path filter="url(#gouache)" d="M230 250 Q300 150 380 130 Q440 118 500 160 L540 200 Q430 170 360 210 Q290 250 250 330 Z" fill="#8A6A48" opacity={0.85} />
      {/* rocky arch around cave */}
      <path filter="url(#gouache)" d="M300 520 L330 360 Q360 290 430 282 Q500 290 530 360 L560 520 Z" fill="#5A4330" />
      <path d="M362 520 L372 392 Q392 336 432 334 Q472 336 492 392 L500 520 Z" fill="url(#caveIn)" />
      {/* boulders */}
      <ellipse cx={318} cy={360} rx={44} ry={26} fill="#7D5E40" filter="url(#gouache)" />
      <ellipse cx={548} cy={350} rx={40} ry={24} fill="#7D5E40" filter="url(#gouache)" />
      <ellipse cx={430} cy={286} rx={70} ry={22} fill="#93724F" filter="url(#gouache)" />
      {/* top-down beam into the cave mouth */}
      <g opacity={L}>
        <polygon points="400,0 464,0 520,520 344,520" fill="url(#beam)" filter="url(#blurB)" />
        <ellipse cx={432} cy={470} rx={70} ry={18} fill={C.champagne} opacity={0.55} filter="url(#blurB)" />
      </g>
      {/* foreground rocks */}
      <path filter="url(#gouache)" d="M0 520 L0 450 Q80 420 150 450 Q200 470 250 520 Z" fill="#3F2F22" />
      <path filter="url(#gouache)" d="M860 520 L860 440 Q780 420 700 455 Q660 480 640 520 Z" fill="#3F2F22" />
    </svg>
  );
};
