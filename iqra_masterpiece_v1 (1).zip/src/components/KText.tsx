import React from "react";
import { useCurrentFrame } from "remotion";
import { draw, ease, easeOut, sp } from "../anim";
import { C, FONT, SAFE, TYPE } from "../config";

export type LineKind = "small" | "gold" | "ruby" | "teal" | "sapphire";
export type KLine = { t: string; kind: LineKind; at: number; size?: number; underline?: boolean; serif?: boolean };

/** Rough Bengali width estimate per em for auto-fit (keeps conjuncts inside 880px). */
const fit = (t: string, size: number, isHero: boolean, maxW: number) => {
  const em = isHero ? 0.56 : 0.5;
  const pad = 0;
  const w = t.length * size * em + pad;
  return w > maxW ? Math.floor((maxW / (t.length * em)) * 0.98) : size;
};

/**
 * Kinetic typography block (Rule 12): small connecting line(s) in Hind Siliguri SemiBold slate,
 * and ONE big key phrase per line in Baloo Da 2 ExtraBold, styled gold-block / ruby / teal.
 */
export const KText: React.FC<{
  lines: KLine[];
  gap?: number;
  align?: "center" | "left";
  maxW?: number;
  backing?: boolean;
}> = ({ lines, gap = 10, align = "center", maxW = SAFE.maxTextWidth, backing = false }) => {
  const f = useCurrentFrame();
  const visible = lines.filter((l) => f >= l.at);
  if (visible.length === 0) return null;
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: align === "center" ? "center" : "flex-start",
        gap,
        maxWidth: maxW,
        textAlign: align,
        padding: backing ? "26px 40px" : 0,
        background: backing ? "rgba(255,254,250,0.94)" : undefined,
        borderRadius: backing ? 28 : undefined,
      }}
    >
      {visible.map((l, i) => (
        <Line key={i + l.t} l={l} f={f} maxW={maxW} />
      ))}
    </div>
  );
};

const Line: React.FC<{ l: KLine; f: number; maxW: number }> = ({ l, f, maxW }) => {
  const hero = l.kind !== "small";
  const base = l.size ?? (hero ? TYPE.big : TYPE.small);
  const size = fit(l.t, base, hero, maxW - (l.kind === "gold" ? 60 : 0));
  const k = sp(f, l.at, hero ? "hero" : "soft");
  const op = Math.min(1, k * 1.5);
  const ty = (1 - k) * (hero ? 46 : 26);
  const sc = hero ? 0.82 + 0.18 * k : 1;
  const color =
    l.kind === "small" ? C.slate : l.kind === "ruby" ? C.ruby : l.kind === "teal" ? C.teal : C.sapphire;
  const block = l.kind === "gold" ? ease(f, l.at + 2, l.at + 14, 0, 1, easeOut) : 0;
  const ul = l.underline ? draw(f, l.at + 10, 16) : 0;
  return (
    <div style={{ opacity: op, transform: `translateY(${ty}px) scale(${sc})`, position: "relative", display: "inline-block" }}>
      {l.kind === "gold" ? (
        <div
          style={{
            position: "absolute",
            left: -26,
            right: -26,
            top: size * 0.12,
            bottom: size * 0.02,
            background: C.champagne,
            borderRadius: 16,
            transform: `scaleX(${block})`,
            transformOrigin: "left center",
            boxShadow: "0 10px 26px -14px rgba(217,119,6,0.55)",
          }}
        />
      ) : null}
      <span
        style={{
          position: "relative",
          fontFamily: l.serif ? FONT.serif : hero ? FONT.hero : FONT.body,
          fontWeight: hero ? 800 : 600,
          fontSize: size,
          lineHeight: hero ? 1.22 : 1.3,
          color,
          whiteSpace: "nowrap",
          display: "inline-block",
          paddingTop: hero ? size * 0.06 : 0,
        }}
      >
        {l.t}
      </span>
      {l.underline ? (
        <div style={{ position: "absolute", left: "4%", right: "4%", bottom: -14, height: 7, borderRadius: 4, background: C.gold, transform: `scaleX(${ul})`, transformOrigin: "left center" }} />
      ) : null}
    </div>
  );
};
