import React from "react";
import { useCurrentFrame } from "remotion";
import { ease, easeOut, sp } from "../anim";
import { C, FONT, SHADOW } from "../config";
import { Star8 } from "./Icons";

export const VERSE_WORDS = ["اقْرَأْ", "بِاسْمِ", "رَبِّكَ", "الَّذِي", "خَلَقَ"];

/**
 * Framed manuscript card: RTL Arabic verse with word-by-word warm-gold illumination,
 * Tiro Bangla translation with highlighter sweep, sapphire citation strip.
 */
export const SacredVerseCard: React.FC<{
  wordAt: number[]; // local frames for each Arabic word (reading order)
  transAt: number;
  sweepAt: number;
  sweepEnd: number;
  trans2At: number;
  citeAt: number;
  width?: number;
}> = ({ wordAt, transAt, sweepAt, sweepEnd, trans2At, citeAt, width = 880 }) => {
  const f = useCurrentFrame();
  const sweep = ease(f, sweepAt, sweepEnd, 0, 1, easeOut);
  const t1 = sp(f, transAt, "soft");
  const t2 = sp(f, trans2At, "soft");
  const cite = sp(f, citeAt, "soft");
  return (
    <div
      style={{
        position: "relative",
        width,
        boxSizing: "border-box",
        padding: "64px 34px 0",
        background: `linear-gradient(180deg, #FFFEFA 0%, #FFFBEE 100%)`,
        borderRadius: 22,
        border: `2px solid ${C.gold}`,
        boxShadow: `${SHADOW}, inset 0 0 0 10px #FFFEFA, inset 0 0 0 11.5px rgba(217,119,6,0.45)`,
        overflow: "hidden",
      }}
    >
      {/* ornamental gold geometric corner brackets */}
      {[
        { l: 22, t: 22, r: 0 },
        { r2: 22, t: 22, r: 90 },
        { r2: 22, b: 92, r: 180 },
        { l: 22, b: 92, r: 270 },
      ].map((p, i) => (
        <svg
          key={i}
          width={64}
          height={64}
          viewBox="0 0 64 64"
          style={{ position: "absolute", left: p.l, right: p.r2, top: p.t, bottom: p.b, transform: `rotate(${p.r}deg)` }}
        >
          <path d="M6 40 V6 H40" fill="none" stroke={C.gold} strokeWidth={3} strokeLinecap="round" />
          <path d="M14 30 V14 H30" fill="none" stroke={C.gold} strokeWidth={1.6} opacity={0.75} />
          <polygon points="14,8 18,14 14,20 10,14" fill={C.gold} transform="translate(0 0)" />
        </svg>
      ))}
      <div style={{ display: "flex", justifyContent: "center", marginBottom: 6, opacity: Math.min(1, sp(f, wordAt[0] - 6) * 1.4) }}>
        <Star8 size={34} color={C.gold} sw={5} p={ease(f, wordAt[0] - 8, wordAt[0] + 10, 0, 1)} />
      </div>
      {/* Arabic — RTL, embedded bidi, each word illuminated as recited */}
      <div
        dir="rtl"
        lang="ar"
        style={{
          unicodeBidi: "embed",
          direction: "rtl",
          textAlign: "center",
          fontFamily: FONT.arabic,
          fontSize: 80,
          lineHeight: 1.75,
          color: C.sapphire,
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          gap: "0 10px",
        }}
      >
        {VERSE_WORDS.map((w, i) => {
          const a = wordAt[i];
          const k = sp(f, a - 4, "soft");
          const glow = ease(f, a, a + 8, 0, 1, easeOut) * (1 - 0.55 * ease(f, a + 14, a + 30, 0, 1));
          return (
            <span
              key={i}
              style={{
                position: "relative",
                display: "inline-block",
                opacity: Math.min(1, k * 1.4),
                transform: `translateY(${(1 - k) * 24}px)`,
                padding: "0 6px",
                borderRadius: 18,
                background: `rgba(253,230,138,${0.85 * glow})`,
                boxShadow: glow > 0.02 ? `0 0 ${40 * glow}px rgba(253,230,138,${0.9 * glow})` : undefined,
                color: f >= a ? C.sapphire : "rgba(20,30,48,0.35)",
              }}
            >
              {w}
            </span>
          );
        })}
      </div>
      {/* Gold divider */}
      <svg width="100%" height={30} viewBox="0 0 780 30" style={{ marginTop: 6, opacity: t1 }}>
        <line x1={120} y1={15} x2={360} y2={15} stroke={C.gold} strokeWidth={2} />
        <line x1={420} y1={15} x2={660} y2={15} stroke={C.gold} strokeWidth={2} />
        <polygon points="390,4 401,15 390,26 379,15" fill={C.gold} />
      </svg>
      {/* Bengali translation in Tiro Bangla */}
      <div style={{ textAlign: "center", fontFamily: FONT.serif, color: C.slate, padding: "10px 0 34px" }}>
        <div style={{ opacity: Math.min(1, t1 * 1.4), transform: `translateY(${(1 - t1) * 20}px)`, fontSize: 56, lineHeight: 1.5 }}>
          <span style={{ position: "relative", display: "inline-block", padding: "0 10px" }}>
            <span
              style={{
                position: "absolute",
                left: 0,
                right: 0,
                top: "18%",
                bottom: "6%",
                background: C.champagne,
                borderRadius: 10,
                transform: `scaleX(${sweep})`,
                transformOrigin: "left center",
              }}
            />
            <span style={{ position: "relative", color: C.sapphire }}>"পড়ো তোমার প্রতিপালকের নামে,</span>
          </span>
        </div>
        <div style={{ opacity: Math.min(1, t2 * 1.4), transform: `translateY(${(1 - t2) * 20}px)`, fontSize: 52, lineHeight: 1.5, fontStyle: "italic" }}>
          যিনি সবকিছু সৃষ্টি করেছেন"
        </div>
      </div>
      {/* citation strip */}
      <div
        style={{
          margin: "0 -34px",
          height: 78,
          background: C.sapphire,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 16,
          transform: `translateY(${(1 - cite) * 78}px)`,
        }}
      >
        <Star8 size={22} color={C.champagne} sw={6} />
        <span style={{ fontFamily: FONT.body, fontWeight: 600, fontSize: 34, color: C.white, letterSpacing: 0.5 }}>
          Surah Al-Alaq (96:1) — The First Revelation
        </span>
        <Star8 size={22} color={C.champagne} sw={6} />
      </div>
    </div>
  );
};
