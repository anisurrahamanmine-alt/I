import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { C } from "../config";

/** Soft top-down light cone + floor glow. k = intensity 0..1. Light always from ABOVE. */
export const TopLight: React.FC<{ k: number; x?: number; floorY?: number; width?: number; warm?: boolean }> = ({
  k,
  x = 540,
  floorY = 1150,
  width = 420,
  warm = true,
}) => {
  const f = useCurrentFrame();
  if (k <= 0.001) return null;
  const breathe = 0.92 + Math.sin(f * 0.05) * 0.08;
  const tint = warm ? "253,230,138" : "255,255,255";
  return (
    <AbsoluteFill style={{ pointerEvents: "none", opacity: k * breathe }}>
      <svg width={1080} height={1920}>
        <defs>
          <linearGradient id="cone" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={`rgb(${tint})`} stopOpacity={0.7} />
            <stop offset="0.65" stopColor={`rgb(${tint})`} stopOpacity={0.18} />
            <stop offset="1" stopColor={`rgb(${tint})`} stopOpacity={0} />
          </linearGradient>
          <radialGradient id="floor" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor={`rgb(${tint})`} stopOpacity={0.55} />
            <stop offset="1" stopColor={`rgb(${tint})`} stopOpacity={0} />
          </radialGradient>
          <filter id="soft" x="-30%" y="-10%" width="160%" height="120%">
            <feGaussianBlur stdDeviation="28" />
          </filter>
        </defs>
        <polygon
          points={`${x - 110},0 ${x + 110},0 ${x + width},${floorY} ${x - width},${floorY}`}
          fill="url(#cone)"
          filter="url(#soft)"
        />
        <ellipse cx={x} cy={floorY} rx={width * 1.05} ry={70} fill="url(#floor)" />
      </svg>
    </AbsoluteFill>
  );
};

/** Gentle archival vignette on the outer edges. */
export const Vignette: React.FC<{ k: number }> = ({ k }) =>
  k <= 0.001 ? null : (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        opacity: k,
        background: `radial-gradient(ellipse 78% 62% at 50% 40%, transparent 55%, rgba(20,30,48,0.22) 100%)`,
      }}
    />
  );

/** Soft white flash (max 35%). */
export const Flash: React.FC<{ k: number }> = ({ k }) =>
  k <= 0.001 ? null : <AbsoluteFill style={{ backgroundColor: C.white, opacity: Math.min(0.35, k * 0.35), pointerEvents: "none" }} />;

/** Floating dust motes drifting in a light beam (foreground layer). */
export const Dust: React.FC<{ k: number; x?: number; y0?: number; y1?: number; spread?: number; n?: number }> = ({
  k,
  x = 540,
  y0 = 200,
  y1 = 1100,
  spread = 300,
  n = 22,
}) => {
  const f = useCurrentFrame();
  if (k <= 0.001) return null;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", opacity: k }}>
      <svg width={1080} height={1920}>
        {Array.from({ length: n }).map((_, i) => {
          const seed = (i * 9301 + 49297) % 233280;
          const r = seed / 233280;
          const yy = y0 + (((r * 997 + f * (0.4 + r * 0.6)) % (y1 - y0)) + (y1 - y0)) % (y1 - y0);
          const xx = x + (r - 0.5) * spread * 2 * ((yy - y0) / (y1 - y0) * 0.7 + 0.3) + Math.sin(f * 0.03 + i) * 10;
          return <circle key={i} cx={xx} cy={yy} r={1.6 + r * 2.4} fill={C.gold} opacity={0.18 + 0.3 * Math.sin(f * 0.07 + i) ** 2} />;
        })}
      </svg>
    </AbsoluteFill>
  );
};
