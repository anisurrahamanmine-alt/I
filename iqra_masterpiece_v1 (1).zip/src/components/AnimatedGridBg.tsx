import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { globalCam } from "../cameras";
import { C } from "../config";

const GRAIN =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' width='260' height='260'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0.35  0 0 0 0 0.3  0 0 0 0 0.22  0 0 0 0.09 0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>`
  );

// 8-point star (two overlapping squares) outline
const star8 = (cx: number, cy: number, r: number) => {
  const pts: string[] = [];
  for (let i = 0; i < 16; i++) {
    const a = (Math.PI / 8) * i - Math.PI / 2;
    const rr = i % 2 === 0 ? r : r * 0.62;
    pts.push(`${(cx + Math.cos(a) * rr).toFixed(1)},${(cy + Math.sin(a) * rr).toFixed(1)}`);
  }
  return pts.join(" ");
};

/** Always-moving alabaster canvas: linen grain, soft washes, dot grid + Islamic star lattice + compass arcs. */
export const AnimatedGridBg: React.FC = () => {
  const f = useCurrentFrame();
  const cam = globalCam(f);
  const px = -cam.x * 0.3 + f * 0.18;
  const py = -cam.y * 0.3 + f * 0.32;
  const s = 1 + (cam.s - 1) * 0.3;
  const w1 = Math.sin(f * 0.012) * 40;
  const w2 = Math.cos(f * 0.009) * 50;

  return (
    <AbsoluteFill style={{ backgroundColor: C.alabaster, overflow: "hidden" }}>
      {/* soft multi-colour washes */}
      <AbsoluteFill
        style={{
          background: `radial-gradient(620px 520px at ${120 + w1}px ${180 + w2}px, rgba(142,162,232,0.12), transparent 70%),
             radial-gradient(640px 560px at ${980 - w2}px ${1540 + w1}px, rgba(125,211,192,0.11), transparent 70%),
             radial-gradient(560px 460px at ${1000 + w1}px ${260 - w2}px, rgba(253,230,138,0.12), transparent 70%),
             radial-gradient(520px 420px at ${80 - w1}px ${1180 + w2}px, rgba(253,230,138,0.08), transparent 70%)`,
        }}
      />
      <svg width={1080} height={1920} style={{ position: "absolute", inset: 0, transform: `scale(${s})`, transformOrigin: "540px 720px" }}>
        <defs>
          <pattern id="dots" width={48} height={48} patternUnits="userSpaceOnUse" patternTransform={`translate(${px % 48} ${py % 48})`}>
            <circle cx={24} cy={24} r={1.7} fill={C.sapphire} opacity={0.1} />
          </pattern>
          <pattern
            id="lattice"
            width={192}
            height={192}
            patternUnits="userSpaceOnUse"
            patternTransform={`translate(${(px * 0.6) % 192} ${(py * 0.6) % 192})`}
          >
            <polygon points={star8(96, 96, 46)} fill="none" stroke={C.sapphire} strokeWidth={1.1} opacity={0.055} />
            <rect x={70} y={70} width={52} height={52} fill="none" stroke={C.teal} strokeWidth={1} opacity={0.05} transform="rotate(45 96 96)" />
            <line x1={0} y1={96} x2={50} y2={96} stroke={C.sapphire} strokeWidth={1} opacity={0.045} />
            <line x1={142} y1={96} x2={192} y2={96} stroke={C.sapphire} strokeWidth={1} opacity={0.045} />
            <line x1={96} y1={0} x2={96} y2={50} stroke={C.sapphire} strokeWidth={1} opacity={0.045} />
            <line x1={96} y1={142} x2={96} y2={192} stroke={C.sapphire} strokeWidth={1} opacity={0.045} />
          </pattern>
          <pattern id="graph" width={240} height={240} patternUnits="userSpaceOnUse" patternTransform={`translate(${px % 240} ${py % 240})`}>
            <path d="M240 0 L0 0 0 240" fill="none" stroke={C.sapphire} strokeWidth={1} opacity={0.05} />
          </pattern>
        </defs>
        <rect width={1080} height={1920} fill="url(#graph)" />
        <rect width={1080} height={1920} fill="url(#dots)" />
        <rect width={1080} height={1920} fill="url(#lattice)" />
        {/* astrolabe / compass arcs, slowly rotating */}
        <g transform={`rotate(${f * 0.04} 1080 0)`} opacity={0.07}>
          <circle cx={1080} cy={0} r={520} fill="none" stroke={C.gold} strokeWidth={1.4} />
          <circle cx={1080} cy={0} r={600} fill="none" stroke={C.sapphire} strokeWidth={1} strokeDasharray="4 10" />
          <circle cx={1080} cy={0} r={700} fill="none" stroke={C.teal} strokeWidth={1} />
        </g>
        <g transform={`rotate(${-f * 0.035} 0 1920)`} opacity={0.07}>
          <circle cx={0} cy={1920} r={560} fill="none" stroke={C.teal} strokeWidth={1.4} />
          <circle cx={0} cy={1920} r={650} fill="none" stroke={C.sapphire} strokeWidth={1} strokeDasharray="3 12" />
          <circle cx={0} cy={1920} r={760} fill="none" stroke={C.gold} strokeWidth={1} />
        </g>
      </svg>
      <AbsoluteFill style={{ backgroundImage: `url("${GRAIN}")`, backgroundSize: "260px 260px", opacity: 0.9 }} />
    </AbsoluteFill>
  );
};
