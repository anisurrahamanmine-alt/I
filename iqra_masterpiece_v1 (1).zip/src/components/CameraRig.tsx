import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { camAt, CAMS } from "../cameras";
import { SAFE } from "../config";

/**
 * Virtual camera with 3-layer parallax.
 * bg layer 0.3x, mid (children) 1.0x, fg layer 1.25x.
 */
export const CameraRig: React.FC<{
  scene: number;
  children: React.ReactNode;
  bg?: React.ReactNode;
  fg?: React.ReactNode;
  originY?: number;
}> = ({ scene, children, bg, fg, originY = SAFE.opticalCenter }) => {
  const f = useCurrentFrame();
  const c = camAt(CAMS[scene], f);
  const layer = (k: number): React.CSSProperties => ({
    transform: `translate(${c.x * k}px, ${c.y * k}px) scale(${1 + (c.s - 1) * k})`,
    transformOrigin: `540px ${originY}px`,
  });
  return (
    <AbsoluteFill>
      {bg ? <AbsoluteFill style={layer(0.3)}>{bg}</AbsoluteFill> : null}
      <AbsoluteFill style={layer(1)}>{children}</AbsoluteFill>
      {fg ? <AbsoluteFill style={layer(1.25)}>{fg}</AbsoluteFill> : null}
    </AbsoluteFill>
  );
};

/** Hero Visual Stage: flex column centred around the optical centre (160–1320px). */
export const Stage: React.FC<{ children: React.ReactNode; gap?: number; style?: React.CSSProperties }> = ({
  children,
  gap = 36,
  style,
}) => (
  <div
    style={{
      position: "absolute",
      left: 0,
      right: 0,
      top: SAFE.stageTop,
      height: SAFE.stageBottom - SAFE.stageTop,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      gap,
      ...style,
    }}
  >
    {children}
  </div>
);

/** Absolutely positioned layer within the stage area, centred horizontally. */
export const Layer: React.FC<{ children: React.ReactNode; top?: number; style?: React.CSSProperties }> = ({
  children,
  top,
  style,
}) => (
  <div
    style={{
      position: "absolute",
      left: 0,
      right: 0,
      top: top ?? SAFE.stageTop,
      height: top === undefined ? SAFE.stageBottom - SAFE.stageTop : undefined,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: top === undefined ? "center" : "flex-start",
      ...style,
    }}
  >
    {children}
  </div>
);
