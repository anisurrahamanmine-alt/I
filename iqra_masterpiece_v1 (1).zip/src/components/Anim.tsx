import React from "react";
import { Sequence, Audio, staticFile, useCurrentFrame } from "remotion";
import { dimK, ease, easeIn, exitK, idle, sp, SPR } from "../anim";

type Kind = "pop" | "up" | "down" | "left" | "right" | "fade" | "zoom" | "drop";

/**
 * Every element enters animated (never visible before `at`), optionally dims when a newer
 * hero arrives, and exits cleanly over the last frames before `out`.
 */
export const Anim: React.FC<{
  at: number;
  out?: number;
  outDur?: number;
  type?: Kind;
  exitType?: Kind;
  dist?: number;
  cfg?: keyof typeof SPR;
  dim?: number;
  undim?: number;
  dimTo?: number;
  float?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({ at, out, outDur = 12, type = "up", exitType, dist = 70, cfg = "soft", dim, undim, dimTo = 0.25, float = 0, style, children }) => {
  const f = useCurrentFrame();
  if (f < at) return null;
  if (out !== undefined && f >= out) return null;
  const k = sp(f, at, cfg);
  const o = out !== undefined ? exitK(f, out, outDur) : 1;
  let d = dim !== undefined ? dimK(f, dim) : 0;
  if (undim !== undefined) d *= 1 - dimK(f, undim);
  const inv = 1 - k;
  let tx = 0;
  let ty = 0;
  let sc = 1;
  switch (type) {
    case "pop": sc = 0.55 + 0.45 * k; break;
    case "zoom": sc = 1.25 - 0.25 * k; break;
    case "up": ty = dist * inv; break;
    case "down": ty = -dist * inv; break;
    case "left": tx = dist * inv; break;
    case "right": tx = -dist * inv; break;
    case "drop": ty = -dist * 2 * inv; sc = 1.06 - 0.06 * k; break;
    default: break;
  }
  const xo = 1 - o;
  switch (exitType ?? "fade") {
    case "left": tx -= 140 * ease(xo, 0, 1, 0, 1, easeIn); break;
    case "right": tx += 140 * xo; break;
    case "up": ty -= 90 * xo; break;
    case "down": ty += 90 * xo; break;
    case "zoom": sc *= 1 + 0.25 * xo; break;
    case "pop": sc *= 1 - 0.35 * xo; break;
    default: sc *= 1 - 0.04 * xo; break;
  }
  const fl = float ? idle(f - at, float, 0.05) : 0;
  const op = Math.min(1, k * 1.4) * o * (1 - d * (1 - dimTo));
  return (
    <div
      style={{
        opacity: op,
        transform: `translate(${tx}px, ${ty + fl}px) scale(${sc})`,
        filter: d > 0.01 ? `blur(${d * 3}px)` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/** Sound effect at a scene-local frame. */
export const Sfx: React.FC<{ at: number; src: string; v?: number; dur?: number }> = ({ at, src, v = 0.2, dur = 150 }) => (
  <Sequence from={Math.max(0, at)} durationInFrames={dur} layout="none">
    <Audio src={staticFile(`sfx/${src}.wav`)} volume={v} />
  </Sequence>
);
