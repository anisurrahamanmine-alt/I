import React from "react";
import { C, SHADOW } from "../config";

/** Crisp elevated ivory editorial card with fine gold corner marks. */
export const EdCard: React.FC<{
  w?: number;
  h?: number;
  pad?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
  accent?: string;
  ornate?: boolean;
}> = ({ w = 860, h, pad = 40, children, style, accent = C.gold, ornate = false }) => (
  <div
    style={{
      position: "relative",
      width: w,
      height: h,
      padding: pad,
      boxSizing: "border-box",
      background: C.ivory,
      borderRadius: 20,
      border: `1.5px solid ${C.hairline}`,
      boxShadow: SHADOW,
      ...style,
    }}
  >
    <Corners accent={accent} ornate={ornate} />
    {children}
  </div>
);

const Corners: React.FC<{ accent: string; ornate: boolean }> = ({ accent, ornate }) => {
  const s = ornate ? 46 : 26;
  const corner = (rot: number, pos: React.CSSProperties, key: string) => (
    <svg key={key} width={s} height={s} viewBox="0 0 46 46" style={{ position: "absolute", ...pos, transform: `rotate(${rot}deg)` }}>
      <path d="M4 30 V4 H30" fill="none" stroke={accent} strokeWidth={ornate ? 2.6 : 2.2} strokeLinecap="round" />
      {ornate ? (
        <>
          <path d="M11 22 V11 H22" fill="none" stroke={accent} strokeWidth={1.4} strokeLinecap="round" opacity={0.8} />
          <polygon points="11,11 15,7 19,11 15,15" fill={accent} opacity={0.85} transform="translate(-4 -4)" />
        </>
      ) : null}
    </svg>
  );
  const i = 12;
  return (
    <>
      {corner(0, { left: i, top: i }, "tl")}
      {corner(90, { right: i, top: i }, "tr")}
      {corner(180, { right: i, bottom: i }, "br")}
      {corner(270, { left: i, bottom: i }, "bl")}
    </>
  );
};

/** Ivory chip / pill */
export const Chip: React.FC<{ children: React.ReactNode; style?: React.CSSProperties; border?: string }> = ({
  children,
  style,
  border = C.hairline,
}) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      gap: 18,
      padding: "18px 34px",
      background: C.ivory,
      borderRadius: 999,
      border: `2px solid ${border}`,
      boxShadow: SHADOW,
      ...style,
    }}
  >
    {children}
  </div>
);
