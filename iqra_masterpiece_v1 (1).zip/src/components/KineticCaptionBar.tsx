import React from "react";
import { useCurrentFrame } from "remotion";
import { ease, easeOut } from "../anim";
import { C, FONT, SAFE } from "../config";
import { WORDS, sec } from "../timeline";

type Chunk = { words: { t: string; s: number; e: number }[]; s: number; e: number };

const clean = (w: string) => w.replace(/[।,]/g, "");

// One line, max 3 words / ~20 characters, broken on cues and punctuation.
const CHUNKS: Chunk[] = (() => {
  const out: Chunk[] = [];
  let cur: Chunk | null = null;
  WORDS.forEach((w, i) => {
    const t = clean(w.w);
    const len = cur ? cur.words.map((x) => x.t).join(" ").length + 1 + t.length : t.length;
    const prev = WORDS[i - 1];
    const breakPunct = prev ? /[।?!,]$/.test(prev.w) : false;
    if (!cur || cur.words.length >= 3 || len > 21 || breakPunct || w.s - (prev?.e ?? 0) > 0.45) {
      if (cur) out.push(cur);
      cur = { words: [], s: w.s, e: w.e };
    }
    cur.words.push({ t, s: w.s, e: w.e });
    cur.e = w.e;
  });
  if (cur) out.push(cur);
  // hold until next chunk if gap is small
  for (let i = 0; i < out.length; i++) {
    const nx = out[i + 1];
    out[i].e = nx && nx.s - out[i].e < 0.7 ? nx.s : out[i].e + 0.3;
  }
  return out;
})();

/** Lower kinetic caption: sapphire pill, active word on champagne-gold block (3-state colour). */
export const KineticCaptionBar: React.FC = () => {
  const f = useCurrentFrame();
  const tsec = f / 30;
  const ci = CHUNKS.findIndex((c) => tsec >= c.s - 0.02 && tsec < c.e);
  if (ci < 0) return null;
  const c = CHUNKS[ci];
  const k = ease(f, sec(c.s) - 1, sec(c.s) + 5, 0, 1, easeOut);
  const out = ease(f, sec(c.e) - 4, sec(c.e), 1, 0);
  const isLastBeforeGap = !CHUNKS[ci + 1] || CHUNKS[ci + 1].s - c.e > 0.01;
  const op = isLastBeforeGap ? Math.min(k, out) : k;
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        top: SAFE.captionTop,
        height: SAFE.captionBottom - SAFE.captionTop,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        pointerEvents: "none",
      }}
    >
      <div
        style={{
          opacity: op,
          transform: `translateY(${(1 - k) * 16}px) scale(${0.96 + 0.04 * k})`,
          maxWidth: 840,
          display: "flex",
          alignItems: "center",
          gap: 14,
          padding: "16px 34px 18px",
          borderRadius: 999,
          background: "rgba(20,30,48,0.92)",
          border: "2px solid rgba(253,230,138,0.35)",
          boxShadow: "0 18px 40px -18px rgba(20,30,48,0.6)",
          whiteSpace: "nowrap",
        }}
      >
        {c.words.map((w, i) => {
          const active = tsec >= w.s - 0.03 && (i === c.words.length - 1 ? true : tsec < c.words[i + 1].s - 0.03);
          const past = !active && tsec >= w.s;
          const a = active ? ease(f, sec(w.s) - 2, sec(w.s) + 3, 0, 1, easeOut) : 0;
          return (
            <span
              key={i}
              style={{
                position: "relative",
                fontFamily: FONT.body,
                fontWeight: 700,
                fontSize: 60,
                lineHeight: 1.25,
                padding: "2px 12px",
                borderRadius: 12,
                color: active ? C.sapphire : C.white,
                opacity: active || past ? 1 : 0.45,
                background: active ? `rgba(253,230,138,${a})` : "transparent",
                transform: `scale(${1 + 0.05 * a})`,
              }}
            >
              {w.t}
            </span>
          );
        })}
      </div>
    </div>
  );
};
