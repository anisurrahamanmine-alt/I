import React from "react";
import { C } from "../config";

/** All icons are crisp inline SVG vectors (no emoji / glyph icons). p = draw-on progress 0..1. */
type P = { size?: number; color?: string; p?: number; sw?: number; fill?: string; style?: React.CSSProperties };

const S = (p: number) => ({ pathLength: 1, strokeDasharray: 1, strokeDashoffset: 1 - p });
const base = (size: number, style?: React.CSSProperties) => ({
  width: size,
  height: size,
  viewBox: "0 0 100 100",
  style: { overflow: "visible" as const, ...style },
});
const st = (color: string, sw: number) => ({
  fill: "none",
  stroke: color,
  strokeWidth: sw,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
});

export const Mosque: React.FC<P> = ({ size = 80, color = C.sapphire, p = 1, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path {...S(p)} d="M22 84 V56 Q22 34 50 26 Q78 34 78 56 V84 Z" />
      <path {...S(p)} d="M50 26 V16 M46 14 Q50 8 54 14" />
      <path {...S(p)} d="M10 84 V46 M10 46 L6 52 M10 46 L14 52 M90 84 V46 M90 46 L86 52 M90 46 L94 52" />
      <path {...S(p)} d="M41 84 V68 Q50 58 59 68 V84" />
      <path {...S(p)} d="M4 86 H96" />
    </g>
  </svg>
);

export const Crescent: React.FC<P> = ({ size = 80, color = C.teal, p = 1, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path {...S(p)} d="M62 14 A38 38 0 1 0 84 70 A30 30 0 1 1 62 14 Z" />
      <path {...S(p)} d="M74 26 L77 34 L85 35 L79 40 L81 48 L74 44 L67 48 L69 40 L63 35 L71 34 Z" strokeWidth={sw * 0.7} />
    </g>
  </svg>
);

export const CharityHand: React.FC<P> = ({ size = 80, color = C.gold, p = 1, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <circle {...S(p)} cx={56} cy={26} r={14} />
      <path {...S(p)} d="M50 26 H62 M56 20 V32" strokeWidth={sw * 0.7} />
      <path {...S(p)} d="M8 66 H24 L42 58 Q50 56 52 62 L40 68 H58 L82 54 Q90 52 90 60 L64 80 Q58 84 50 84 H24 L8 84" />
    </g>
  </svg>
);

export const Shield: React.FC<P> = ({ size = 80, color = C.ruby, p = 1, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path {...S(p)} d="M50 8 L84 20 V46 Q84 74 50 92 Q16 74 16 46 V20 Z" />
      <path {...S(p)} d="M34 50 H66" strokeWidth={sw * 1.3} />
    </g>
  </svg>
);

export const QMark: React.FC<P> = ({ size = 80, color = C.gold, p = 1, sw = 9, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path {...S(p)} d="M30 34 Q30 12 50 12 Q72 12 72 32 Q72 46 56 52 Q50 56 50 66" />
    </g>
    <circle cx={50} cy={86} r={sw * 0.75} fill={color} opacity={p > 0.85 ? 1 : 0} />
  </svg>
);

export const Cross: React.FC<P> = ({ size = 80, color = C.ruby, p = 1, sw = 10, style }) => {
  const a = Math.min(1, p * 2);
  const b = Math.max(0, p * 2 - 1);
  return (
    <svg {...base(size, style)}>
      <g {...st(color, sw)}>
        <path {...S(a)} d="M16 16 L84 84" />
        <path {...S(b)} d="M84 16 L16 84" />
      </g>
    </svg>
  );
};

export const Check: React.FC<P> = ({ size = 80, color = C.teal, p = 1, sw = 10, style }) => (
  <svg {...base(size, style)}>
    <path {...st(color, sw)} {...S(p)} d="M14 54 L40 78 L88 22" />
  </svg>
);

export const Slash: React.FC<P & { w?: number; h?: number }> = ({ w = 400, h = 60, color = C.ruby, p = 1, sw = 9, style }) => (
  <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{ overflow: "visible", ...style }}>
    <path {...st(color, sw)} {...S(p)} d={`M6 ${h * 0.75} Q ${w / 2} ${h * 0.35} ${w - 6} ${h * 0.2}`} />
  </svg>
);

export const BookOpen: React.FC<P & { open?: number }> = ({ size = 80, color = C.teal, p = 1, sw = 5, open = 1, fill, style }) => {
  const lift = 14 * open;
  return (
    <svg {...base(size, style)}>
      <g {...st(color, sw)}>
        <path {...S(p)} d={`M50 ${30 - lift * 0.2} Q30 ${18 - lift * 0.3} 8 ${24 - lift * 0.2} V80 Q30 74 50 84 Z`} fill={fill ?? "none"} />
        <path {...S(p)} d={`M50 ${30 - lift * 0.2} Q70 ${18 - lift * 0.3} 92 ${24 - lift * 0.2} V80 Q70 74 50 84 Z`} fill={fill ?? "none"} />
        <path {...S(p)} d="M18 40 Q30 36 40 42 M18 54 Q30 50 40 56 M60 42 Q70 36 82 40 M60 56 Q70 50 82 54" strokeWidth={sw * 0.6} />
      </g>
    </svg>
  );
};

export const BookClosed: React.FC<P> = ({ size = 80, color = C.sapphire, p = 1, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path {...S(p)} d="M22 10 H78 V90 H22 Q14 90 14 82 V18 Q14 10 22 10 Z" />
      <path {...S(p)} d="M26 10 V90" />
      <path {...S(p)} d="M52 36 L56 46 L66 47 L58 54 L61 64 L52 58 L43 64 L46 54 L38 47 L48 46 Z" strokeWidth={sw * 0.7} />
    </g>
  </svg>
);

export const ScrollSeal: React.FC<P> = ({ size = 80, color = C.gold, p = 1, sw = 5, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path {...S(p)} d="M20 14 H74 Q82 14 82 22 V74 M20 14 Q12 14 12 22 Q12 30 20 30 H28 V84 Q28 90 34 90 H86 Q92 90 92 82 Q92 74 84 74 H40" />
      <circle {...S(p)} cx={62} cy={58} r={14} />
      <path {...S(p)} d="M62 48 L65 55 L72 56 L67 61 L68 68 L62 64 L56 68 L57 61 L52 56 L59 55 Z" strokeWidth={sw * 0.6} />
    </g>
  </svg>
);

export const PauseIcon: React.FC<P> = ({ size = 60, color = C.gold, p = 1, sw = 6, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <circle {...S(p)} cx={50} cy={50} r={40} />
      <path {...S(p)} d="M40 34 V66 M60 34 V66" strokeWidth={sw * 1.3} />
    </g>
  </svg>
);

export const Star8: React.FC<P> = ({ size = 60, color = C.gold, p = 1, sw = 4, fill, style }) => {
  const pts: string[] = [];
  for (let i = 0; i < 16; i++) {
    const a = (Math.PI / 8) * i - Math.PI / 2;
    const r = i % 2 === 0 ? 46 : 28;
    pts.push(`${(50 + Math.cos(a) * r).toFixed(1)},${(50 + Math.sin(a) * r).toFixed(1)}`);
  }
  return (
    <svg {...base(size, style)}>
      <polygon {...st(color, sw)} {...S(p)} points={pts.join(" ")} fill={fill ?? "none"} />
    </svg>
  );
};

export const Compass: React.FC<P & { rot?: number }> = ({ size = 160, color = C.gold, p = 1, sw = 4, rot = 0, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <circle {...S(p)} cx={50} cy={50} r={44} />
      <circle {...S(p)} cx={50} cy={50} r={36} strokeWidth={sw * 0.5} strokeDasharray="2 4" />
      {[0, 45, 90, 135, 180, 225, 270, 315].map((a) => (
        <line key={a} x1={50} y1={8} x2={50} y2={a % 90 === 0 ? 16 : 13} transform={`rotate(${a} 50 50)`} opacity={p} />
      ))}
    </g>
    <g transform={`rotate(${rot} 50 50)`} opacity={p}>
      <polygon points="50,14 57,50 50,56 43,50" fill={C.gold} />
      <polygon points="50,86 57,50 50,44 43,50" fill={C.sapphire} />
      <circle cx={50} cy={50} r={4} fill={C.ivory} stroke={C.sapphire} strokeWidth={2} />
    </g>
  </svg>
);

export const Person: React.FC<P> = ({ size = 50, color = C.sapphire, style }) => (
  <svg {...base(size, style)}>
    <circle cx={50} cy={30} r={17} fill={color} />
    <path d="M18 92 Q18 54 50 54 Q82 54 82 92 Z" fill={color} />
  </svg>
);

export const Heart: React.FC<P> = ({ size = 60, color = C.ruby, sw = 6, fill, style }) => (
  <svg {...base(size, style)}>
    <path {...st(color, sw)} fill={fill ?? "none"} d="M50 84 L18 52 Q6 38 16 24 Q30 10 50 30 Q70 10 84 24 Q94 38 82 52 Z" />
  </svg>
);

export const ShareIc: React.FC<P> = ({ size = 60, color = C.teal, sw = 6, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <circle cx={74} cy={22} r={12} />
      <circle cx={26} cy={50} r={12} />
      <circle cx={74} cy={78} r={12} />
      <path d="M36 44 L64 28 M36 56 L64 72" />
    </g>
  </svg>
);

export const BellIc: React.FC<P> = ({ size = 60, color = C.sapphire, sw = 6, style }) => (
  <svg {...base(size, style)}>
    <g {...st(color, sw)}>
      <path d="M24 70 V44 Q24 20 50 20 Q76 20 76 44 V70 L84 78 H16 Z" />
      <path d="M42 86 Q50 94 58 86" />
      <path d="M50 12 V20" />
    </g>
  </svg>
);

export const Cursor: React.FC<P> = ({ size = 70, style }) => (
  <svg {...base(size, style)}>
    <path d="M22 8 L22 78 L40 62 L52 90 L64 84 L52 58 L76 56 Z" fill={C.ivory} stroke={C.sapphire} strokeWidth={5} strokeLinejoin="round" />
  </svg>
);

export const PlayDot: React.FC<{ size?: number; color?: string }> = ({ size = 18, color = C.gold }) => (
  <svg width={size} height={size} viewBox="0 0 20 20">
    <polygon points="10,1 13,7 19,10 13,13 10,19 7,13 1,10 7,7" fill={color} />
  </svg>
);
