import React from "react";
import { useCurrentFrame } from "remotion";
import { ease, easeOut, sp } from "../anim";
import { C } from "../config";
import { BookOpen } from "./Icons";

const SKIN = "#E7B68E";
const SKIN_SH = "#D49C74";
const HAIR = "#231C18";

type Pt = [number, number];
const mix = (a: Pt, b: Pt, t: number): Pt => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

const Arm: React.FC<{ s: Pt; e: Pt; h: Pt; color: string; w?: number }> = ({ s, e, h, color, w = 34 }) => (
  <g>
    <path d={`M${s[0]} ${s[1]} L${e[0]} ${e[1]} L${h[0]} ${h[1]}`} fill="none" stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round" />
    <circle cx={h[0]} cy={h[1]} r={w * 0.58} fill={SKIN} />
  </g>
);

const Head: React.FC<{ cx: number; cy: number; tilt: number; blink: number; brow?: number; band?: boolean; smile?: number }> = ({
  cx,
  cy,
  tilt,
  blink,
  brow = 0,
  band = false,
  smile = 0,
}) => (
  <g transform={`rotate(${tilt} ${cx} ${cy + 60})`}>
    <rect x={cx - 18} y={cy + 40} width={36} height={40} rx={10} fill={SKIN_SH} />
    <circle cx={cx} cy={cy} r={60} fill={SKIN} />
    <path d={`M${cx - 62} ${cy - 2} Q${cx - 66} ${cy - 70} ${cx} ${cy - 68} Q${cx + 62} ${cy - 70} ${cx + 62} ${cy - 6} Q${cx + 40} ${cy - 40} ${cx - 6} ${cy - 38} Q${cx - 40} ${cy - 36} ${cx - 62} ${cy - 2} Z`} fill={HAIR} />
    <circle cx={cx - 60} cy={cy + 6} r={10} fill={SKIN_SH} />
    <circle cx={cx + 60} cy={cy + 6} r={10} fill={SKIN_SH} />
    {band ? (
      <g>
        <rect x={cx - 64} y={cy - 12} width={128} height={28} rx={8} fill={C.ruby} />
        <path d={`M${cx + 60} ${cy + 2} q22 6 30 26 M${cx + 60} ${cy + 6} q14 14 14 34`} stroke={C.ruby} strokeWidth={9} fill="none" strokeLinecap="round" />
      </g>
    ) : (
      <g>
        <ellipse cx={cx - 22} cy={cy + 2} rx={6} ry={7 * blink} fill={C.sapphire} />
        <ellipse cx={cx + 22} cy={cy + 2} rx={6} ry={7 * blink} fill={C.sapphire} />
        <path d={`M${cx - 34} ${cy - 16 - brow} q12 -7 22 0 M${cx + 12} ${cy - 16 - brow * 1.4} q12 -7 22 0`} stroke={HAIR} strokeWidth={5} fill="none" strokeLinecap="round" />
      </g>
    )}
    <path d={`M${cx - 14} ${cy + 30} Q${cx} ${cy + 36 + smile * 8} ${cx + 14} ${cy + 30}`} stroke="#8A4B3A" strokeWidth={5} fill="none" strokeLinecap="round" />
  </g>
);

const blinkAt = (f: number) => {
  const m = f % 96;
  return m > 88 ? 0.15 : 1;
};

/** Modern thinker: hand rises to chin, head tilts, thought dots pop. */
export const Thinker: React.FC<{ at: number; chinAt: number; tiltAt: number; size?: number }> = ({ at, chinAt, tiltAt, size = 420 }) => {
  const f = useCurrentFrame();
  const t = sp(f, chinAt, "soft");
  const tilt = ease(f, tiltAt, tiltAt + 16, 0, -9, easeOut) + Math.sin(f * 0.05) * 1.2;
  const sweater = C.sapphire;
  const sh: Pt = [212, 268];
  const e = mix([236, 370], [252, 352], t);
  const h = mix([236, 452], [176, 230], t);
  const dots = [0, 1, 2].map((i) => sp(f, tiltAt + 6 + i * 7, "hero"));
  return (
    <svg width={size} height={size * 1.5} viewBox="0 0 300 450" style={{ overflow: "visible" }}>
      {dots.map((d, i) => (
        <circle key={i} cx={230 + i * 22} cy={96 - i * 26} r={(7 + i * 4) * d} fill={C.gold} opacity={0.85} />
      ))}
      <path d="M58 450 V318 Q58 252 150 248 Q242 252 242 318 V450 Z" fill={sweater} />
      <path d="M118 252 Q150 284 182 252" fill="none" stroke={C.champagne} strokeWidth={8} strokeLinecap="round" />
      <Arm s={[88, 270]} e={[66, 370]} h={[78, 446]} color={sweater} />
      <Head cx={150} cy={160} tilt={tilt} blink={blinkAt(f - at)} brow={t * 4} />
      <Arm s={sh} e={e} h={h} color={"#1D2A44"} />
    </svg>
  );
};

/** Learner: opens a book and raises it; head tilts up. */
export const Learner: React.FC<{ at: number; openAt: number; raiseAt: number; size?: number }> = ({ at, openAt, raiseAt, size = 380 }) => {
  const f = useCurrentFrame();
  const r = sp(f, raiseAt, "soft");
  const o = ease(f, openAt, openAt + 14, 0, 1, easeOut);
  const bob = Math.sin((f - at) * 0.06) * 3;
  const sweater = C.teal;
  const handY = 380 - r * 70 + bob;
  const hl: Pt = [118, handY];
  const hr: Pt = [242, handY];
  const tilt = -6 * r + Math.sin(f * 0.04) * 1;
  return (
    <svg width={size} height={size * 1.4} viewBox="0 0 360 504" style={{ overflow: "visible" }}>
      <path d="M70 504 V372 Q70 300 180 296 Q290 300 290 372 V504 Z" fill={sweater} />
      <path d="M146 300 Q180 330 214 300" fill="none" stroke={C.ivory} strokeWidth={8} strokeLinecap="round" />
      <Head cx={180} cy={206} tilt={tilt} blink={blinkAt(f - at)} smile={r} />
      <Arm s={[100, 320]} e={[70, 410 - r * 60]} h={hl} color={"#0B7C73"} />
      <Arm s={[260, 320]} e={[290, 410 - r * 60]} h={hr} color={"#0B7C73"} />
      <g transform={`translate(${180 - 80} ${handY - 70}) `}>
        <BookOpen size={160} color={C.sapphire} sw={4.5} open={o} fill={C.ivory} />
      </g>
    </svg>
  );
};

/** Blindfolded figure walking with arms stretched (symbol of blind acceptance). */
export const BlindFigure: React.FC<{ at: number; size?: number }> = ({ at, size = 280 }) => {
  const f = useCurrentFrame();
  const w = Math.sin((f - at) * 0.12) * 6;
  const sweater = C.slate;
  return (
    <svg width={size} height={size * 1.5} viewBox="0 0 300 450" style={{ overflow: "visible" }}>
      <g transform={`rotate(${Math.sin((f - at) * 0.08) * 2} 150 420)`}>
        <path d="M58 450 V318 Q58 252 150 248 Q242 252 242 318 V450 Z" fill={sweater} />
        <Arm s={[92, 276]} e={[30, 300 + w]} h={[-24, 296 + w]} color={sweater} />
        <Arm s={[208, 276]} e={[262, 310 - w]} h={[316, 302 - w]} color={sweater} />
        <Head cx={150} cy={160} tilt={Math.sin((f - at) * 0.07) * 4} blink={1} band />
      </g>
    </svg>
  );
};
