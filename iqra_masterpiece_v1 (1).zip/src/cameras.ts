import { Easing, interpolate } from "remotion";
import { SCENES, seqFrom } from "./timeline";

/** Camera keyframe in scene-local frames. s = scale, x/y = pan (px), e = easing into this key. */
export type CamKey = { f: number; s: number; x?: number; y?: number; e?: "io" | "out" | "back" | "in" };
export type Cam = { s: number; x: number; y: number };

const EASE = {
  io: Easing.inOut(Easing.cubic),
  out: Easing.out(Easing.cubic),
  back: Easing.out(Easing.back(1.6)),
  in: Easing.in(Easing.cubic),
};

export const camAt = (keys: CamKey[], f: number): Cam => {
  if (f <= keys[0].f) return { s: keys[0].s, x: keys[0].x ?? 0, y: keys[0].y ?? 0 };
  for (let i = 1; i < keys.length; i++) {
    const a = keys[i - 1];
    const b = keys[i];
    if (f <= b.f) {
      const t = interpolate(f, [a.f, b.f], [0, 1], { easing: EASE[b.e ?? "io"] });
      return {
        s: a.s + (b.s - a.s) * t,
        x: (a.x ?? 0) + ((b.x ?? 0) - (a.x ?? 0)) * t,
        y: (a.y ?? 0) + ((b.y ?? 0) - (a.y ?? 0)) * t,
      };
    }
  }
  const l = keys[keys.length - 1];
  return { s: l.s, x: l.x ?? 0, y: l.y ?? 0 };
};

// Per-scene camera choreography (local frames, sequences start 6f before the cut).
// Alternating slow zoom-ins / zoom-outs + snappy punch-ins on reveals.
export const CAMS: Record<number, CamKey[]> = {
  1: [
    { f: 0, s: 0.9 },
    { f: 18, s: 1.03, e: "back" },
    { f: 140, s: 1.07, y: -10 },
    { f: 178, s: 1.06 },
    { f: 216, s: 1.0, e: "out" },
    { f: 250, s: 1.03 },
    { f: 262, s: 1.03 },
  ],
  2: [
    { f: 0, s: 1.03 },
    { f: 9, s: 1.07, e: "back" },
    { f: 175, s: 1.12, y: 10 },
    { f: 190, s: 1.0, e: "out" },
    { f: 236, s: 1.08, y: 0 },
    { f: 257, s: 2.6, y: 40, e: "in" },
  ],
  3: [
    { f: 0, s: 1.1 },
    { f: 16, s: 1.0, e: "out" },
    { f: 110, s: 1.03, x: 8 },
    { f: 205, s: 1.08, x: 0 },
    { f: 262, s: 1.0, e: "out" },
    { f: 286, s: 1.02 },
  ],
  4: [
    { f: 0, s: 1.04, x: 30 },
    { f: 60, s: 1.0, x: 0 },
    { f: 95, s: 1.0 },
    { f: 270, s: 1.05 },
    { f: 307, s: 1.03, x: -30, e: "in" },
  ],
  5: [
    { f: 0, s: 1.0, x: 30 },
    { f: 30, s: 1.0, x: 0, e: "out" },
    { f: 100, s: 1.02 },
    { f: 180, s: 1.035, y: -8 },
    { f: 280, s: 1.05, y: 0 },
    { f: 380, s: 1.065, y: 6 },
    { f: 445, s: 1.03 },
    { f: 486, s: 1.0, y: -30 },
  ],
  6: [
    { f: 0, s: 1.02, y: 30 },
    { f: 40, s: 1.0, y: 0, e: "out" },
    { f: 60, s: 1.0 },
    { f: 270, s: 1.07 },
    { f: 301, s: 1.04 },
  ],
  7: [
    { f: 0, s: 1.0 },
    { f: 120, s: 1.04 },
    { f: 175, s: 1.06 },
    { f: 255, s: 1.07 },
    { f: 330, s: 1.0, e: "out" },
    { f: 378, s: 1.0, y: 0 },
  ],
  8: [
    { f: 0, s: 1.0, y: 20 },
    { f: 15, s: 1.03, y: 0, e: "back" },
    { f: 180, s: 1.05, y: -14 },
    { f: 236, s: 1.04, x: -30, e: "in" },
  ],
  9: [
    { f: 0, s: 1.0, x: 30 },
    { f: 30, s: 1.0, x: 0, e: "out" },
    { f: 100, s: 1.04 },
    { f: 200, s: 1.0 },
    { f: 270, s: 1.05 },
    { f: 294, s: 2.2, y: 60, e: "in" },
  ],
  10: [
    { f: 0, s: 1.12 },
    { f: 18, s: 1.0, e: "out" },
    { f: 150, s: 1.06 },
  ],
  11: [
    { f: 0, s: 1.04 },
    { f: 60, s: 1.0, e: "out" },
    { f: 180, s: 1.03 },
    { f: 253, s: 1.05 },
  ],
};

/** Global camera (for background parallax) at an absolute frame. */
export const globalCam = (abs: number): Cam => {
  let id = 1;
  for (const s of SCENES) if (abs >= s.start) id = s.id;
  return camAt(CAMS[id], abs - seqFrom(id));
};
