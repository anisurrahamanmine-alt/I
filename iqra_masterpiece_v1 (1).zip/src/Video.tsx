import React from "react";
import { AbsoluteFill, Audio, Sequence, staticFile } from "remotion";
import { AnimatedGridBg } from "./components/AnimatedGridBg";
import { KineticCaptionBar } from "./components/KineticCaptionBar";
import { C } from "./config";
import { useFonts } from "./fonts";
import { seqDur, seqFrom } from "./timeline";
import { Scene01 } from "./scenes/Scene01";
import { Scene02 } from "./scenes/Scene02";
import { Scene03 } from "./scenes/Scene03";
import { Scene04 } from "./scenes/Scene04";
import { Scene05 } from "./scenes/Scene05";
import { Scene06 } from "./scenes/Scene06";
import { Scene07 } from "./scenes/Scene07";
import { Scene08 } from "./scenes/Scene08";
import { Scene09 } from "./scenes/Scene09";
import { Scene10 } from "./scenes/Scene10";
import { Scene11 } from "./scenes/Scene11";

const SCENE_COMPONENTS = [Scene01, Scene02, Scene03, Scene04, Scene05, Scene06, Scene07, Scene08, Scene09, Scene10, Scene11];

export const Video: React.FC = () => {
  const ready = useFonts();
  return (
    <AbsoluteFill style={{ backgroundColor: C.alabaster }}>
      <AnimatedGridBg />
      {ready
        ? SCENE_COMPONENTS.map((S, i) => (
            <Sequence key={i} from={seqFrom(i + 1)} durationInFrames={seqDur(i + 1)} name={`Scene${String(i + 1).padStart(2, "0")}`}>
              <S />
            </Sequence>
          ))
        : null}
      {ready ? <KineticCaptionBar /> : null}
      <Audio src={staticFile("audio/voiceover.mp3")} volume={1} />
    </AbsoluteFill>
  );
};
