import { useEffect, useState } from "react";
import { continueRender, delayRender, staticFile } from "remotion";

type FontDef = { family: string; file: string; weight?: string; style?: string };

export const FONT_FILES: FontDef[] = [
  { family: "BalooDa2", file: "fonts/BalooDa2-Variable.ttf", weight: "400 800" },
  { family: "HindSiliguri", file: "fonts/HindSiliguri-SemiBold.ttf", weight: "600" },
  { family: "HindSiliguri", file: "fonts/HindSiliguri-Bold.ttf", weight: "700" },
  { family: "TiroBangla", file: "fonts/TiroBangla-Regular.ttf", weight: "400" },
  { family: "TiroBangla", file: "fonts/TiroBangla-Italic.ttf", weight: "400", style: "italic" },
  { family: "TatsamBengali", file: "fonts/TatsamBengaliRnd-Bold.otf", weight: "700" },
  { family: "AmiriQuran", file: "fonts/AmiriQuran-Regular.ttf", weight: "400" },
  { family: "ScheherazadeNew", file: "fonts/ScheherazadeNew-Bold.ttf", weight: "700" },
];

const TIMEOUT = 25000;
let loadedOnce = false;

/**
 * Loads all fonts inside a React hook: delayRender in useState, FontFace load in useEffect,
 * 25s timeout per font, then continueRender. Never at module level.
 */
export const useFonts = () => {
  const [handle] = useState(() => (loadedOnce ? null : delayRender("Loading fonts", { timeoutInMilliseconds: 60000 })));
  const [ready, setReady] = useState(loadedOnce);

  useEffect(() => {
    if (handle === null) return;
    let cancelled = false;
    const withTimeout = (p: Promise<unknown>) =>
      Promise.race([p, new Promise((res) => setTimeout(res, TIMEOUT))]);

    Promise.all(
      FONT_FILES.map((f) => {
        const face = new FontFace(f.family, `url('${staticFile(f.file)}')`, {
          weight: f.weight ?? "400",
          style: f.style ?? "normal",
        });
        return withTimeout(
          face
            .load()
            .then((loaded) => {
              (document.fonts as unknown as { add: (f: FontFace) => void }).add(loaded);
            })
            .catch((e) => console.warn("Font failed", f.file, e))
        );
      })
    )
      .then(() => withTimeout(document.fonts.ready))
      .finally(() => {
        if (cancelled) return;
        loadedOnce = true;
        setReady(true);
        continueRender(handle);
      });
    return () => {
      cancelled = true;
    };
  }, [handle]);

  return ready;
};
