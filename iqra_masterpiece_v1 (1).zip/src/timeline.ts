import WORDS_RAW from "./words.json";
import { FPS } from "./config";

export type Word = { w: string; s: number; e: number; cue: number };
export const WORDS = WORDS_RAW as Word[];

export const sec = (s: number) => Math.round(s * FPS);

/** Absolute frame where spoken word #i starts (indices = src/words.json order). */
export const WF = (i: number) => sec(WORDS[i].s);
export const WE = (i: number) => sec(WORDS[i].e);

/** Overlap between scenes (frames). Each scene sequence starts HALF earlier and ends HALF later. */
export const OVERLAP = 12;
const HALF = OVERLAP / 2;

// Scene cut points (absolute frames) — set on real pauses in the voiceover.
export const SCENES = [
  { id: 1, start: 0, end: 256 },
  { id: 2, start: 256, end: 501 },
  { id: 3, start: 501, end: 775 },
  { id: 4, start: 775, end: 1070 },
  { id: 5, start: 1070, end: 1544 },
  { id: 6, start: 1544, end: 1833 },
  { id: 7, start: 1833, end: 2199 },
  { id: 8, start: 2199, end: 2423 },
  { id: 9, start: 2423, end: 2705 },
  { id: 10, start: 2705, end: 2849 },
  { id: 11, start: 2849, end: 3096 },
] as const;

export const TOTAL_FRAMES = 3096;

export const seqFrom = (id: number) => {
  const s = SCENES[id - 1];
  return Math.max(0, s.start - (id === 1 ? 0 : HALF));
};
export const seqDur = (id: number) => {
  const s = SCENES[id - 1];
  const from = seqFrom(id);
  const to = id === SCENES.length ? TOTAL_FRAMES : s.end + HALF;
  return to - from;
};

/** Helper used inside a scene: local frame of word i (relative to scene sequence start). */
export const localAt = (id: number) => {
  const from = seqFrom(id);
  return (i: number) => WF(i) - from;
};
export const localAbs = (id: number) => {
  const from = seqFrom(id);
  return (abs: number) => abs - from;
};
