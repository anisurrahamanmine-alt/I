import { Easing, interpolate, spring } from "remotion";
import { FPS } from "./config";

// Motion mood: reverent + curious -> smooth springs, low overshoot; punch only on key reveals.
export const SPR = {
  soft: { damping: 18, stiffness: 110, mass: 0.9 },
  hero: { damping: 13, stiffness: 120, mass: 0.9 },
  punch: { damping: 10, stiffness: 180, mass: 0.7 },
  slow: { damping: 22, stiffness: 60, mass: 1 },
};

export const sp = (f: number, start: number, cfg: keyof typeof SPR = "soft", dur?: number) =>
  spring({ frame: f - start, fps: FPS, config: SPR[cfg], durationInFrames: dur });

export const ease = (
  f: number,
  a: number,
  b: number,
  from = 0,
  to = 1,
  easing: (t: number) => number = Easing.inOut(Easing.cubic)
) =>
  interpolate(f, [a, b], [from, to], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing,
  });

export const easeOut = Easing.out(Easing.cubic);
export const easeIn = Easing.in(Easing.cubic);

/** 1 -> 0 over the last `dur` frames before `end`. */
export const exitK = (f: number, end: number, dur = 12) => ease(f, end - dur, end, 1, 0, easeIn);

/** Dim factor to ~0.25 when a newer hero arrives. */
export const dimK = (f: number, at: number, dur = 14) => ease(f, at, at + dur, 0, 1);

/** Gentle idle float (never fully static). */
export const idle = (f: number, amp = 6, speed = 0.045, phase = 0) => Math.sin(f * speed + phase) * amp;

/** Draw-on progress for SVG paths using pathLength=1. */
export const draw = (f: number, start: number, dur = 14) => ease(f, start, start + dur, 0, 1, easeOut);
